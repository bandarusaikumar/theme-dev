<?php 
$theme_options = emall_get_theme_options();
$show_social_text = $theme_options['ts_enable_header_social_text'];
$facebook_url = $theme_options['ts_facebook_url'];
$facebook_text = $theme_options['ts_facebook_text'];
$twitter_url = $theme_options['ts_twitter_url'];
$twitter_text = $theme_options['ts_twitter_text'];
$youtube_url = $theme_options['ts_youtube_url'];
$youtube_text = $theme_options['ts_youtube_text'];
$instagram_url = $theme_options['ts_instagram_url'];
$instagram_text = $theme_options['ts_instagram_text'];
$linkedin_url = $theme_options['ts_linkedin_url'];
$linkedin_text = $theme_options['ts_linkedin_text'];
$custom_url = $theme_options['ts_custom_social_url'];
$custom_class = $theme_options['ts_custom_social_class'];
$custom_text = $theme_options['ts_custom_social_text'];
?>
<div class="social-icons">
	<ul>
		<?php do_action('ts_header_social_icons_before'); ?>
			
		<?php if( $facebook_url && ( !$show_social_text || ( $show_social_text && $facebook_text ) ) ): ?>
		<li class="facebook" >
			<a class="icon-social-facebook" href="<?php echo esc_url($facebook_url); ?>" target="_blank">
			<?php if( $show_social_text && $facebook_text ){ ?>
				<span><?php echo esc_html($facebook_text); ?></span>
			<?php } ?>
			</a>
		</li>
		<?php endif; ?>

		<?php if( $twitter_url && ( !$show_social_text || ( $show_social_text && $twitter_text ) ) ): ?>
		<li class="twitter" >
			<a class="icon-social-twitter" href="<?php echo esc_url($twitter_url); ?>" target="_blank">
			<?php if( $show_social_text && $twitter_text ){ ?>
				<span><?php echo esc_html($twitter_text); ?></span>
			<?php } ?>
			</a>
		</li>
		<?php endif; ?>
		
		<?php if( $instagram_url && ( !$show_social_text || ( $show_social_text && $instagram_text ) ) ): ?>
		<li class="instagram" >
			<a class="icon-social-instagram" href="<?php echo esc_url($instagram_url); ?>" target="_blank">
			<?php if( $show_social_text && $instagram_text ){ ?>
				<span><?php echo esc_html($instagram_text); ?></span>
			<?php } ?>
			</a>
		</li>
		<?php endif; ?>
		
		<?php if( $youtube_url && ( !$show_social_text || ( $show_social_text && $youtube_text ) ) ): ?>
		<li class="youtube" >
			<a class="icon-social-youtube" href="<?php echo esc_url($youtube_url); ?>" target="_blank">
				<?php if( $show_social_text && $youtube_text ){ ?>
					<span><?php echo esc_html($youtube_text); ?></span>
				<?php } ?>
			</a>
		</li>
		<?php endif; ?>
		
		<?php if( $linkedin_url && ( !$show_social_text || ( $show_social_text && $linkedin_text ) ) ): ?>
		<li class="linkedin" >
			<a class="icon-social-linkedin" href="<?php echo esc_url($linkedin_url); ?>" target="_blank">
			<?php if( $show_social_text && $linkedin_text ){ ?>
				<span><?php echo esc_html($linkedin_text); ?></span>
			<?php } ?>
			</a>
		</li>
		<?php endif; ?>
		
		<?php if( $custom_url && ( !$show_social_text || ( $show_social_text && $custom_text ) ) ): ?>
		<li class="custom">
			<a class="<?php echo esc_attr($custom_class) ?>" href="<?php echo esc_url($custom_url); ?>" target="_blank">
			<?php if( $show_social_text && $custom_text ){ ?>
				<span><?php echo esc_html($custom_text); ?></span>
			<?php } ?>
			</a>
		</li>
		<?php endif; ?>
		
		<?php do_action('ts_header_social_icons_after'); ?>
	</ul>
</div>