<?php 
if( !class_exists('TS_Importer') ){
	class TS_Importer{
		function __construct(){
			add_filter( 'ocdi/plugin_page_title', array($this, 'import_notice') );
			
			add_filter( 'ocdi/plugin_page_setup', array($this, 'import_page_setup') );
			add_action( 'ocdi/before_widgets_import', array($this, 'before_widgets_import') );
			add_filter( 'ocdi/import_files', array($this, 'import_files') );
			add_action( 'ocdi/after_import', array($this, 'after_import_setup') );
			
			if( wp_doing_ajax() && isset($_POST['action']) && 'ocdi_import_demo_data' == $_POST['action'] ){
				add_filter('upload_mimes', array($this, 'allow_upload_font_files'));
			}
		}
		
		function import_notice( $plugin_title ){
			$allowed_html = array(
				'a' => array( 'href' => array(), 'target' => array() )
			);
			ob_start();
			?>
			<div class="ts-ocdi-notice-info">
				<p>
					<i class="fas fa-exclamation-circle"></i>
					<span><?php echo wp_kses( __('If you have any problem with importer, please read this article <a href="https://ocdi.com/import-issues/" target="_blank">https://ocdi.com/import-issues/</a> and check your hosting configuration, or contact our support team here <a href="https://skygroup.ticksy.com/" target="_blank">https://skygroup.ticksy.com/</a>.', 'themesky'), $allowed_html ); ?></span>
				</p>
			</div>
			<?php
			$plugin_title .= ob_get_clean();
			return $plugin_title;
		}
		
		function allow_upload_font_files( $existing_mimes = array() ){
			$existing_mimes['svg'] = 'font/svg';
			return $existing_mimes;
		}
		
		function import_page_setup( $default_settings ){
			$default_settings['parent_slug'] = 'themes.php';
			$default_settings['page_title']  = esc_html__( 'Emall - Import Demo Content' , 'themesky' );
			$default_settings['menu_title']  = esc_html__( 'Emall Importer' , 'themesky' );
			$default_settings['capability']  = 'import';
			$default_settings['menu_slug']   = 'emall-importer';
			return $default_settings;
		}
		
		function before_widgets_import(){
			global $wp_registered_sidebars;
			$file_path = dirname(__FILE__) . '/data/custom_sidebars.txt';
			if( file_exists($file_path) ){
				$file_url = plugin_dir_url(__FILE__) . 'data/custom_sidebars.txt';
				$custom_sidebars = wp_remote_get( $file_url );
				$custom_sidebars = maybe_unserialize( trim( $custom_sidebars['body'] ) );
				update_option('ts_custom_sidebars', $custom_sidebars);
				
				if( is_array($custom_sidebars) && !empty($custom_sidebars) ){
					foreach( $custom_sidebars as $name ){
						$custom_sidebar = array(
											'name' 			=> ''.$name.''
											,'id' 			=> sanitize_title($name)
											,'description' 	=> ''
											,'class'		=> 'ts-custom-sidebar'
										);
						if( !isset($wp_registered_sidebars[$custom_sidebar['id']]) ){
							$wp_registered_sidebars[$custom_sidebar['id']] = $custom_sidebar;
						}
					}
				}
			}
		}
		
		function import_files(){
			return array(
				array(
					'import_file_name'            => 'Demo Import'
					,'import_file_url'            => plugin_dir_url( __FILE__ ) . 'data/content.xml'
					,'import_widget_file_url'     => plugin_dir_url( __FILE__ ) . 'data/widget_data.wie'
					,'import_redux'               => array(
						array(
							'file_url'     => plugin_dir_url( __FILE__ ) . 'data/redux.json'
							,'option_name' => 'emall_theme_options'
						)
					)
				)
			);
		}
		
		function after_import_setup(){
			set_time_limit(0);
			
			$this->woocommerce_settings();
			$this->menu_locations();
			$this->set_homepage();
			$this->import_revslider();
			$this->change_url();
			$this->set_elementor_site_settings();
			$this->update_menu_homepage();
			$this->update_product_category_id_in_homepage_content();
			$this->update_theme_options();
			$this->delete_transients();
			$this->update_woocommerce_lookup_table();
			$this->update_menu_term_count();
		}
		
		function get_post_by_title($post_title, $post_type = 'page'){
			$query = new WP_Query(
						array(
							'post_type'               => $post_type
							,'title'                  => $post_title
							,'post_status'            => 'publish'
							,'posts_per_page'         => 1
							,'no_found_rows'          => true
							,'ignore_sticky_posts'    => true
							,'update_post_term_cache' => false
							,'update_post_meta_cache' => false
							,'orderby'                => 'post_date ID'
							,'order'                  => 'ASC'
						)
					);
		 
			if( ! empty( $query->post ) ){
				return $query->post;
			}
			return null;
		}
		
		/* WooCommerce Settings */
		function woocommerce_settings(){
			$woopages = array(
				'woocommerce_shop_page_id' 			=> 'Shop'
				,'woocommerce_cart_page_id' 		=> 'Shopping Cart'
				,'woocommerce_checkout_page_id' 	=> 'Checkout'
				,'woocommerce_myaccount_page_id' 	=> 'My Account'
				,'yith_wcwl_wishlist_page_id' 		=> 'Wishlist'
			);
			foreach( $woopages as $woo_page_name => $woo_page_title ) {
				$woopage = $this->get_post_by_title( $woo_page_title );
				if( isset( $woopage->ID ) && $woopage->ID ) {
					update_option($woo_page_name, $woopage->ID);
				}
			}
			
			if( class_exists('YITH_Woocompare') ){
				update_option('yith_woocompare_compare_button_in_products_list', 'yes');
			}
			
			if( class_exists('YITH_WCWL') ){
				update_option('yith_wcwl_show_on_loop', 'yes');
			}

			if( class_exists('WC_Admin_Notices') ){
				WC_Admin_Notices::remove_notice('install');
			}
			delete_transient( '_wc_activation_redirect' );
			
			flush_rewrite_rules();
		}
		
		/* Menu Locations */
		function menu_locations(){
			$locations = get_theme_mod( 'nav_menu_locations' );
			$menus = wp_get_nav_menus();

			if( $menus ){
				foreach( $menus as $menu ){
					if( $menu->name == 'Main Menu' ){
						$locations['primary'] = $menu->term_id;
					}
					if( $menu->name == 'Secondary Menu' ){
						$locations['secondary'] = $menu->term_id;
					}
					if( $menu->name == 'BROWSER CATEGORIES' ){
						$locations['vertical'] = $menu->term_id;
					}
				}
			}
			set_theme_mod( 'nav_menu_locations', $locations );
		}
		
		/* Set Homepage */
		function set_homepage(){
			$homepage = $this->get_post_by_title( 'Fashion 01' );
			if( isset( $homepage->ID ) ){
				update_option('show_on_front', 'page');
				update_option('page_on_front', $homepage->ID);
			}
		}
		
		/* Import Revolution Slider */
		function import_revslider(){
			if ( class_exists( 'RevSliderSliderImport' ) ) {
				$rev_directory = dirname(__FILE__) . '/data/revslider/';
			
				foreach( glob( $rev_directory . '*.zip' ) as $file ){
					$import = new RevSliderSliderImport();
					$import->import_slider(true, $file);  
				}
			}
		}
		
		/* Change url */
		function change_url(){
			global $wpdb;
			$wp_prefix = $wpdb->prefix;
			$import_url = 'https://import.theme-sky.com/emall';
			$site_url = get_option( 'siteurl', '' );
			$wpdb->query("update `{$wp_prefix}posts` set `guid` = replace(`guid`, '{$import_url}', '{$site_url}');");
			$wpdb->query("update `{$wp_prefix}posts` set `post_content` = replace(`post_content`, '{$import_url}', '{$site_url}');");
			$wpdb->query("update `{$wp_prefix}posts` set `post_excerpt` = replace(`post_excerpt`, '{$import_url}', '{$site_url}');");
			$wpdb->query("update `{$wp_prefix}posts` set `post_title` = replace(`post_title`, '{$import_url}', '{$site_url}') where post_type='nav_menu_item';");
			$wpdb->query("update `{$wp_prefix}postmeta` set `meta_value` = replace(`meta_value`, '{$import_url}', '{$site_url}');");
			$wpdb->query("update `{$wp_prefix}postmeta` set `meta_value` = replace(`meta_value`, '" . str_replace( '/', '\\\/', $import_url ) . "', '" . str_replace( '/', '\\\/', $site_url ) . "') where `meta_key` = '_elementor_data';");
			
			$option_name = 'emall_theme_options';
			$option_ids = array( 
						'ts_logo'
						,'ts_logo_mobile'
						,'ts_logo_sticky'
						,'ts_logo_menu_mobile'
						,'ts_newsletter_signup_image'
						,'ts_custom_loading_image'
						,'ts_need_help_url'
						,'ts_location_link'
						,'ts_track_order_url'
						,'ts_hot_deals_url'
						,'ts_bg_breadcrumbs'
						,'ts_prod_placeholder_img'
						,'ts_prod_custom_tab_content'
						,'ts_prod_ads_banner_content'
						);
			$theme_options = get_option($option_name);
			if( is_array($theme_options) ){
				foreach( $option_ids as $option_id ){
					if( isset($theme_options[$option_id]) ){
						$theme_options[$option_id] = str_replace($import_url, $site_url, $theme_options[$option_id]);
					}
				}
				update_option($option_name, $theme_options);
			}
			
			/* Update Widgets */
			$widgets = array(
				'media_image' 	=> array('url', 'link_url')
				,'text' 		=> array('text')
			);
			foreach( $widgets as $base => $fields ){
				$widget_instances = get_option( 'widget_' . $base, array() );
				if( is_array($widget_instances) ){
					foreach( $widget_instances as $number => $instance ){
						if( $number == '_multiwidget' ){
							continue;
						}
						foreach( $fields as $field ){
							if( isset($widget_instances[$number][$field]) ){
								$widget_instances[$number][$field] = str_replace($import_url, $site_url, $widget_instances[$number][$field]);
							}
						}
					}
					update_option( 'widget_' . $base, $widget_instances );
				}
			}
		}
		
		/* Set Elementor Site Settings */
		function set_elementor_site_settings(){
			$id = 0;
			
			$args = array(
				'post_type' 		=> 'elementor_library'
				,'post_status' 		=> 'public'
				,'posts_per_page'	=> 1
				,'orderby'			=> 'date'
				,'order'			=> 'ASC' /* Date is not changed when import. Use imported post */
			);
			
			$posts = new WP_Query( $args );
			if( $posts->have_posts() ){
				$id = $posts->post->ID;
				update_option('elementor_active_kit', $id);
			}
			
			if( $id ){ /* Fixed width, space, ... if query does not return the imported post */
				$page_settings = get_post_meta($id, '_elementor_page_settings', true);
			
				if( !is_array($page_settings) ){
					$page_settings = array();
				}
					
				if( !isset($page_settings['container_width']) ){
					$page_settings['container_width'] = array();
				}
				
				$page_settings['container_width']['unit'] = '%';
				$page_settings['container_width']['size'] = 100;
				$page_settings['container_width']['sizes'] = array();
				
				if( !isset($page_settings['space_between_widgets']) ){
					$page_settings['space_between_widgets'] = array();
				}
				
				$page_settings['space_between_widgets']['unit'] = 'px';
				$page_settings['space_between_widgets']['column'] = 30;
				$page_settings['space_between_widgets']['row'] = 30;
				$page_settings['space_between_widgets']['sizes'] = array();
				
				$page_settings['page_title_selector'] = 'h1.entry-title';
				
				$page_settings['stretched_section_container'] = '#main';
				
				update_post_meta($id, '_elementor_page_settings', $page_settings);
			}
			
			/* Use color, font from theme */
			update_option('elementor_disable_color_schemes', 'yes');
			update_option('elementor_disable_typography_schemes', 'yes');
		}
		
		/* Set menu for home pages */
		function update_menu_homepage(){
			$pages = array(
						'Fashion 04' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Fashion 05' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Fashion 06' 		=> array('ts_secondary_menu_id' => 'Secondary Menu 2')
						,'Fashion 07' 		=> array('ts_secondary_menu_id' => 'Secondary Menu 2')
						,'Fashion 08' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Fashion 09' 		=> array('ts_secondary_menu_id' => 'Secondary Menu 2')
						,'Fashion 11' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Fashion 14' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Fashion 15' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Furniture 01' 	=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Furniture 03' 	=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Electronic 01' 	=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Electronic 02' 	=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Beauty' 			=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Grocery 02' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Sports' 			=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Watch' 			=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Jewelry' 			=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Shoes 01' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
						,'Shoes 02' 		=> array('ts_menu_id' => 'Menu Fashion FullWidth')
					);
			
			foreach( $pages as $page_title => $page_menus ){
				$page = $this->get_post_by_title( $page_title );
				if( is_object( $page ) ){
					foreach( $page_menus as $option_key => $menu_name ){
						$menu = get_term_by( 'name', $menu_name, 'nav_menu' );
						if( isset($menu->term_id) ){
							update_post_meta( $page->ID, $option_key, $menu->term_id );
						}
					}
				}
			}
		}
		
		/* Update Product Category Id In Homepage Content */
		function update_product_category_id_in_homepage_content(){
			global $wpdb;
			$wp_prefix = $wpdb->prefix;
			
			$pages = array(
						'Fashion 01'	=> array(
								array(
									'188,1099,1100,1101'
									,array( 'Shirt', 'Sandal', 'Trousers', 'Watches' )
									,'ids'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Fashion 02'	=> array(
								array(
									'1104,1105,1108,1106,1107'
									,array( 'Clothes', 'Boot', 'Bags', 'Watch', 'Eyeglass' )
									,'ids'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1043'
									,array( 'Accessories' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 03'	=> array(
								array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1085'
									,array( 'Lifestyle' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 04'	=> array(
								array(
									'1104,188,1119,1114'
									,array( 'Clothes', 'Shirt', 'Sweater', 'Accessories' )
									,'product_cats'
								)
								,array(
									'1116,1109,1146,1124,188,1123,1119,1133,1131'
									,array( 'Men', 'Women', 'Mouse', 'Short', 'Shirt', 'Sandals', 'Sweater', 'Beauty', 'Sunglasses' )
									,'ids'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1'
									,array( 'Handmade' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 05'	=> array(
								array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1041'
									,array( 'LookBook' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 06'	=> array(
								array(
									'1110,1111,1112,1113,1114'
									,array( 'Outfit', 'Shoes', 'Glasses', 'Leather Bag', 'Accessories' )
									,'ids'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1089'
									,array( 'Vogue' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 08'	=> array(
								array(
									'1091'
									,array( 'Street Style' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 09'	=> array(
								array(
									'1109,1117,1119,1116,1120,1118'
									,array( 'Women', 'Sneakers', 'Sweater', 'Men', 'Accessory', 'Trouser' )
									,'ids'
								)
								,array(
									'1104'
									,array( 'Clothes' )
									,'product_cats'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1093'
									,array( 'Trends' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 10'	=> array(
								array(
									'1122,1125,1123,1112,1124,1121'
									,array( 'Handbags', 'Clothing', 'Sandals', 'Glasses', 'Short', 'Jewelrys' )
									,'ids'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1095'
									,array( 'Designers' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 11'	=> array(
								array(
									'1127'
									,array( 'Fashion 11' )
									,'categories'
									,'ts_testimonial_cat'
								)
								,array(
									'1126'
									,array( 'Photography' )
									,'categories'
									,'category'
								)
						)
						,'Fashion 12'	=> array(
								array(
									'1099,188,1112,1122,1124'
									,array( 'Sandal', 'Shirt', 'Glasses', 'Handbags', 'Short' )
									,'ids'
								)
						)
						,'Fashion 13'	=> array(
								array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Fashion 14'	=> array(
								array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Fashion 15'	=> array(
								array(
									'1129,1131,1132,1130,1202'
									,array( 'Women\'s', 'Sunglasses', 'Boots', 'Men\'s', 'Jewelry' )
									,'ids'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Furniture 01'	=> array(
								array(
									'1162,1161,1163,1164'
									,array( 'Chair', 'Lighting', 'Table', 'Sofa' )
									,'product_cats'
								)
								,array(
									'1161,1162,1164,1163'
									,array( 'Lighting', 'Chair', 'Sofa', 'Table' )
									,'product_cats'
								)
								,array(
									'1158'
									,array( 'Furniture' )
									,'categories'
									,'category'
								)
						)
						,'Furniture 02'	=> array(
								array(
									'1271,1272,1273'
									,array( 'Sofas', 'Chairs', 'Lightings' )
									,'product_cats'
								)
								,array(
									'1311'
									,array( 'Decor' )
									,'categories'
									,'category'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Furniture 03'	=> array(
								array(
									'1161,1163,1162'
									,array( 'Lighting', 'Table', 'Chair' )
									,'ids'
								)
								,array(
									'1160'
									,array( 'Furniture' )
									,'product_cats'
								)
								,array(
									'1201'
									,array( 'Cabinet' )
									,'product_cats'
								)
								,array(
									'1165'
									,array( 'Furniture' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Electronic 01'	=> array(
								array(
									'1145,1148,1144,1146,1147'
									,array( 'Headphone', 'Speakers', 'Computers', 'Mouse', 'Smartphone' )
									,'ids'
								)
								,array(
									'1143'
									,array( 'Electronic' )
									,'product_cats'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1142'
									,array( 'Electronic' )
									,'categories'
									,'category'
								)
						)
						,'Electronic 02'	=> array(
								array(
									'1284,1285,1286,1287'
									,array( 'Laptop', 'Camera', 'Headphone', 'Sound' )
									,'product_cats'
								)
								,array(
									'1288,1289,1283,1287,1290,1284,1291,1286,1285,1292'
									,array( 'Phones', 'Gaming', 'Television', 'Sound', 'Mouses', 'Laptop', 'Smartwatch', 'Headphone', 'Camera', 'Washers' )
									,'ids'
								)
								,array(
									'1282'
									,array( 'Other' )
									,'product_cats'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1293'
									,array( 'Technology' )
									,'categories'
									,'category'
								)
						)
						,'Electronic 03'	=> array(
								array(
									'1154,1157,1156,1155,1153,1150,1152,1151'
									,array( 'Camcorder', 'Headphones', 'Smartwatchs', 'Mouse', 'Televisions', 'Laptops', 'Speaker', 'Smartphones' )
									,'ids'
								)
								,array(
									'1143'
									,array( 'Electronic' )
									,'product_cats'
								)
								,array(
									'1147,1157'
									,array( 'Smartphone', 'Headphones' )
									,'product_cats'
								)
								,array(
									'1149'
									,array( 'Technical' )
									,'categories'
									,'category'
								)
						)
						,'Beauty'	=> array(
								array(
									'1137,1134,1136,1135,1138,1139'
									,array( 'Skincare', 'Lips', 'Hair', 'Eye', 'Nails', 'Fragrance' )
									,'ids'
								)
								,array(
									'1133'
									,array( 'Beauty' )
									,'product_cats'
								)
								,array(
									'1141'
									,array( 'Beauty' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1140'
									,array( 'Beauty' )
									,'categories'
									,'category'
								)
						)
						,'Grocery 01'	=> array(
								array(
									'1143,1160,1133,1168'
									,array( 'Electronic', 'Furniture', 'Beauty', 'Sport' )
									,'product_cats'
								)
								,array(
									'1114,1120,1108,1105,1106,1107'
									,array( 'Accessories', 'Accessory', 'Bags', 'Boot', 'Watch', 'Eyeglass' )
									,'ids'
								)
						)
						,'Grocery 02'	=> array(
								array(
									'1104,1160,1143,1133'
									,array( 'Clothes', 'Furniture', 'Electronic', 'Beauty' )
									,'product_cats'
								)
						)
						,'Auto Parts'	=> array(
								array(
									'1218'
									,array( 'Auto Part' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Sports'	=> array(
								array(
									'1169,1170,1171,1172'
									,array( 'Mens', 'Womens', 'Hats', 'Sneaker' )
									,'product_cats'
								)
								,array(
									'1169,1170,1173,1171,1172'
									,array( 'Mens', 'Womens', 'Fitness', 'Hats', 'Sneaker' )
									,'ids'
								)
								,array(
									'1168'
									,array( 'Sport' )
									,'product_cats'
								)
								,array(
									'1174'
									,array( 'Sport' )
									,'categories'
									,'ts_logo_cat'
								)
								,array(
									'1167'
									,array( 'Sport' )
									,'categories'
									,'category'
								)
						)
						,'Watch'	=> array(
								array(
									'1295'
									,array( 'Wristwatch' )
									,'product_cats'
								)
								,array(
									'1294'
									,array( 'Watches' )
									,'categories'
									,'category'
								)
						)
						,'Jewelry'	=> array(
								array(
									'1202'
									,array( 'Jewelry' )
									,'product_cats'
								)
								,array(
									'1141'
									,array( 'Beauty' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Kids'	=> array(
								array(
									'1114,1120,1108,1105,1106,1107'
									,array( 'Accessories', 'Accessory', 'Bags', 'Boot', 'Watch', 'Eyeglass' )
									,'ids'
								)
								,array(
									'1093'
									,array( 'Trends' )
									,'categories'
									,'category'
								)
								,array(
									'583'
									,array( 'Fashion' )
									,'categories'
									,'ts_logo_cat'
								)
						)
						,'Shoes 01'	=> array(
								array(
									'1099'
									,array( 'Sandal' )
									,'product_cats'
								)
								,array(
									'1168,1099'
									,array( 'Sport', 'Sandal' )
									,'product_cats'
								)
						)
					);
			
			$loaded_categories = array();
			
			foreach( $pages as $page_title => $cat_ids_names ){
				$page = $this->get_post_by_title( $page_title );
				if( is_object( $page ) ){
					foreach( $cat_ids_names as $cat_id_name ){
						$key = isset($cat_id_name[2]) ? $cat_id_name[2] : 'ids';
						$taxonomy = isset($cat_id_name[3]) ? $cat_id_name[3] : 'product_cat';
						
						$old_ids = explode(',', $cat_id_name[0]);
						
						$new_ids = array();
						foreach( $cat_id_name[1] as $cat_name ){
							if( $taxonomy == 'product_cat' ){
								$loaded_id = array_search($cat_name, $loaded_categories);
								if( $loaded_id ){
									$new_ids[] = $loaded_id;
								}
								else{
									$cat = get_term_by('name', $cat_name, $taxonomy);
									if( isset($cat->term_id) ){
										$new_ids[] = $cat->term_id;
										$loaded_categories[$cat->term_id] = $cat_name;
									}
								}
							}
							else{
								$cat = get_term_by('name', $cat_name, $taxonomy);
								if( isset($cat->term_id) ){
									$new_ids[] = $cat->term_id;
								}
							}
						}
						
						if( $key == 'parent' || $key == 'parent_cat' ){ /* not multi */
							$old_string = '"' . $key . '":"' . implode('', $old_ids) . '"';
							$new_string = '"' . $key . '":"' . implode('', $new_ids) . '"';
						}
						else{
							$old_string = '"' . $key . '":["' . implode('","', $old_ids) . '"]';
							$new_string = '"' . $key . '":["' . implode('","', $new_ids) . '"]';
						}
						
						$wpdb->query("update `{$wp_prefix}postmeta` set `meta_value` = replace(`meta_value`, '" . $old_string . "', '" . $new_string . "') where `meta_key` = '_elementor_data' and post_id=" . $page->ID . ";");
					}
				}
			}
		}
		
		/* Update Theme Options */
		function update_theme_options(){
			$option_name = 'emall_theme_options';
			$theme_options = get_option($option_name);
			if( !is_array($theme_options) ){
				return;
			}
			
			$posts = array(
						array(
							'ts_footer_block'
							,'Footer Fashion 01'
							,'ts_footer_block'
						)
						,array(
							'ts_prod_summary_custom_content'
							,'Product Summary Content'
							,'ts_custom_block'
						)
						,array(
							'ts_prod_bottom_content'
							,'Product Bottom Content'
							,'ts_custom_block'
						)
					);
					
			foreach( $posts as $post ){
				$key = $post[0];
				$post_title = $post[1];
				$post_type = $post[2];
				
				$p = $this->get_post_by_title( $post_title, $post_type );
				if( isset( $p->ID ) ){
					$theme_options[$key] = $p->ID;
				}
			}
			
			update_option($option_name, $theme_options);	
		}
		
		/* Delete transient */
		function delete_transients(){
			delete_transient('ts_mega_menu_custom_css');
			delete_transient('ts_product_deals_ids');
			delete_transient('wc_products_onsale');
		}
		
		/* Update WooCommerce Loolup Table */
		function update_woocommerce_lookup_table(){
			if( function_exists('wc_update_product_lookup_tables_is_running') && function_exists('wc_update_product_lookup_tables') ){
				if( !wc_update_product_lookup_tables_is_running() ){
					if( !defined('WP_CLI') ){
						define('WP_CLI', true);
					}
					wc_update_product_lookup_tables();
				}
			}
		}
		
		/* Update Menu Term Count - Keep this function until One Click Demo Import fixed */
		function update_menu_term_count(){
			$args = array(
						'taxonomy'		=> 'nav_menu'
						,'hide_empty'	=> 0
						,'fields'		=> 'ids'
					);
			$menus = get_terms( $args );
			if( is_array($menus) ){
				wp_update_term_count_now( $menus, 'nav_menu' );
			}
		}
	}
	new TS_Importer();
}
?>