<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Mailchimp extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-mailchimp';
    }
	
	public function get_title(){
        return esc_html__( 'TS Mailchimp', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-email-field';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'form'
            ,array(
                'label' 		=> esc_html__( 'Form', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> ''
				,'options'		=> $this->get_custom_post_options( 'mc4wp-form' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'layout'
            ,array(
                'label' 		=> esc_html__( 'Layout', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'default' 		=> 'vertical'
				,'options' => array(
					'vertical' => array(
						'title' => esc_html__( 'Vertical', 'themesky' )
						,'icon' => 'eicon-arrow-down'
					)
					,'horizontal' => array(
						'title' => esc_html__( 'Horizontal', 'themesky' )
						,'icon' => 'eicon-arrow-right'
					)
				)
				,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'intro_text'
            ,array(
                'label' 		=> esc_html__( 'Intro text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'title_max_width'
			,array(
				'label' 		=> esc_html__( 'Text Max Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 200
						,'max' 	=> 1000
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .mailchimp-subscription .widget-title-wrapper' => 'max-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
            'ts_alignment'
            ,array(
                'label' 		=> esc_html__( 'Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-mailchimp-subscription-shortcode' => 'text-align: {{VALUE}};'
				)
				,'description' 	=> ''
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_button'
            ,array(
                'label' 		=> esc_html__( 'Button', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'style_button'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'icon'
				,'options'		=> array(
									'text'			=> 'Text'
									,'icon'			=> 'Icon'
								)			
            )
        );
		
		$this->add_responsive_control(
			'icon_size'
			,array(
				'label' 		=> esc_html__( 'Icon Size', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px' 		=> array(
						'min' 	=> 0
						,'max' 	=> 50
					)
				)
				,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .subscribe-email .button i' => 'font-size: {{SIZE}}{{UNIT}};'
				)
				,'condition'	=> array( 
					'style_button' 	=> 'icon'
				)
			)
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' => esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button' => 'color: {{VALUE}}'
					,'{{WRAPPER}} .mailchimp-subscription .processing button.button:before' => 'border-top-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> 'transparent'
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button' => 'background-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'style_button' 	=> 'text'
				)
            )
        );
		
		$this->add_control(
            'button_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button' => 'border-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'style_button' 	=> 'text'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' => esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_text_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#db3c3c'
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button:hover' => 'color: {{VALUE}}'
					,'{{WRAPPER}} .mailchimp-subscription .processing button.button:hover:before' => 'border-top-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_hover'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> 'transparent'
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button:hover' => 'background-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'style_button' 	=> 'text'
				)
            )
        );
		
		$this->add_control(
            'button_border_hover'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#db3c3c'
				,'selectors'	=> array(
					'{{WRAPPER}} .mc4wp-form .subscribe-email .button:hover' => 'border-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'style_button' 	=> 'text'
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_color'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'heading_title'
            ,array(
                'label'     	=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'heading_typography'
				,'selector'			=> '{{WRAPPER}} .mailchimp-subscription .widget-title'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '30'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '42'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_decoration', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
            'title_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'.mailchimp-subscription .widget-title' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'title_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .mailchimp-subscription .widget-title' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_intro'
            ,array(
                'label'     	=> esc_html__( 'Intro Text', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'heading_intro_typography'
				,'selector'			=> '{{WRAPPER}} .mailchimp-subscription .newsletter'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '16'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '24'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_decoration', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
            'intro_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription .newsletter' => 'color: {{VALUE}}'
				)
            )
        );
		$this->add_responsive_control(
			'intro_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .mailchimp-subscription .newsletter' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_input'
            ,array(
                'label'     	=> esc_html__( 'Input', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'style_input'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'default'
				,'options'		=> array(
									'line'			=> 'Line'
									,'default'		=> 'Default'
								)			
            )
        );
		
		$this->add_control(
            'input_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription input[type="email"], 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'input_text_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color Hover', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription input[type="email"]:hover, 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]:hover,
					{{WRAPPER}} .mailchimp-subscription input[type="email"]:focus, 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]:focus,
					{{WRAPPER}} .mailchimp-subscription input[type="email"]:focus:invalid:focus, 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]:focus:invalid:focus' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'input_placeholder_color'
            ,array(
                'label'     	=> esc_html__( 'Placeholder Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#888888'
				,'selectors'	=> array(
					'{{WRAPPER}} input::placeholder' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'input_background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#ffffff'
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription input[type="email"], 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"],
					{{WRAPPER}} .mailchimp-subscription input[type="email"]:focus, 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]:focus' => 'background-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'style_input' 	=> 'default'
				)
            )
        );
		
		$this->add_control(
            'input_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#e1e1e1'
				,'selectors'	=> array(
					'{{WRAPPER}} .mailchimp-subscription input[type="email"], 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"],
					{{WRAPPER}} .mailchimp-subscription input[type="email"]:focus, 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]:focus' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'input_radius'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Input Radius', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .mailchimp-subscription input[type="email"], 
					{{WRAPPER}} .mailchimp-subscription input[type="tel"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
				,'condition'	=> array( 
					'style_input' 	=> 'default'
				)
			)
		);

		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'title'				=> ''
			,'intro_text'		=> ''
			,'form'				=> ''
			,'ts_alignment'		=> ''
			,'style_button'		=> 'text'
			,'style_input'		=> 'default'
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( !class_exists('TS_Mailchimp_Subscription_Widget') ){
			return;
		}
		
		$intro_text_html = '';
		if( $intro_text ){
			$intro_text_html = '<div class="newsletter"><p>' . esc_html($intro_text) . '</p></div>';
			$intro_text = ''; /* Dont show in widget content */
		}
		
		$args = array(
			'before_widget' => '<section class="%s">'
			,'after_widget' => '</section>'
			,'before_title' => '<div class="widget-title-wrapper"><h3 class="widget-title heading-title">'
			,'after_title'  => '</h3>' . $intro_text_html . '</div>'
		);

		$title = wp_kses($title, array('br' => array()));
		$instance = compact('title', 'intro_text', 'form');
		
		$classes = array();
		$classes[] = 'style-' . $layout;
		$classes[] = 'style-button-' . $style_button;
		$classes[] = 'style-input-' . $style_input;
		
		echo '<div class="ts-mailchimp-subscription-shortcode '.implode(' ', $classes).'" >';
		
		the_widget('TS_Mailchimp_Subscription_Widget', $instance, $args);
		
		echo '</div>';
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Mailchimp() );