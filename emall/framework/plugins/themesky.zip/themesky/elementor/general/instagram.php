<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Instagram extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-instagram';
    }
	
	public function get_title(){
        return esc_html__( 'TS Instagram', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-instagram-gallery';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 		=> esc_html__( 'General', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'access_token'
            ,array(
                'label' 		=> esc_html__( 'Access Token', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
                ,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'number'
            ,array(
                'label'     	=> esc_html__( 'Number Of Photos', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 9
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'columns'
            ,array(
                'label'     	=> esc_html__( 'Columns', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 5
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'item_gap'
            ,array(
                'label' 		=> esc_html__( 'Item Gap', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'target'
            ,array(
                'label' 		=> esc_html__( 'Target', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> '_self'
				,'options'		=> array(
					'_self'		=> esc_html__( 'Self', 'themesky' )
					,'_blank'	=> esc_html__( 'New window tab', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'cache_time'
            ,array(
                'label'     	=> esc_html__( 'Cache Time (hours)', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 24
				,'min'      	=> 1
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'is_slider'
            ,array(
                'label' 		=> esc_html__( 'Enable Slider', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'only_slider_mobile'
            ,array(
                'label' 		=> esc_html__( 'Only Enable Slider on Device', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> esc_html__( 'Show Grid on desktop and only enable Slider on device', 'themesky' )
            )
        );
		
		$this->add_product_slider_controls_basic();
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'title'					=> ''
			,'access_token'			=> ''
			,'number'				=> 9
			,'columns'				=> 5
			,'target'				=> '_self'
			,'cache_time'			=> 24
			,'is_slider'			=> 0
			,'only_slider_mobile'	=> 0
			,'show_nav'				=> 0
			,'show_dots'			=> 0
			,'auto_play'			=> 0
			,'loop'					=> 1
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		$classes = array();
		if( $item_gap ){
			$classes[] = 'has-gap';
		}
		
		
		if( !class_exists('TS_Instagram_Widget') ){
			return;
		}
		
		if( !$access_token ){
			return;
		}
		
		if( $only_slider_mobile && !wp_is_mobile() ){
			$is_slider = 0;
		}
		
		$args = array(
			'before_widget' => '<section class="%s">'
			,'after_widget' => '</section>'
			,'before_title' => '<div class="widget-title-wrapper"><h3 class="widget-title heading-title">'
			,'after_title'  => '</h3></div>'
		);
		?>
		<div class="ts-instagram-elementor-widget <?php echo esc_attr(implode(' ', $classes)) ?>">
			<?php if( $title ){ ?>
			<header class="shortcode-heading-wrapper">
				<h3 class="shortcode-title">
					<?php echo esc_html($title); ?>
				</h3>
			</header>
			<?php
			}
			
			$title = ''; /* dont show title of wp widget */
			$instance = compact('title', 'access_token', 'number', 'columns', 'target', 'cache_time', 'is_slider', 'show_nav', 'show_dots', 'auto_play', 'loop');
			the_widget('TS_Instagram_Widget', $instance, $args);
		?>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Instagram() );