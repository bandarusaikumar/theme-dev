<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Blogs extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-blogs';
    }
	
	public function get_title(){
        return esc_html__( 'TS Blogs', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-posts-grid';
	}
	
	public function get_script_depends(){
		if( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ){
			return array('isotope');
		}
		return array();
	}
	
	public function get_image_size_options(){
		$image_sizes = array();
		
		$default_image_sizes = array('thumbnail', 'medium', 'medium_large', 'large');
		foreach( $default_image_sizes as $size ){
			$image_sizes[$size] = array(
				'width' 	=> (int) get_option( $size . '_size_w' )
				,'height' 	=> (int) get_option( $size . '_size_h' )
			);
		}

		$image_sizes = array_merge( $image_sizes, wp_get_additional_image_sizes() );
		
		$options = array();
		$options[''] = esc_html__( 'Default', 'themesky' );
		
		foreach( $image_sizes as $key => $attributes ){
			$title = ucwords( str_replace( '_', ' ', $key ) );
			if( is_array( $attributes ) ){
				$title .= sprintf( ' - %d x %d', $attributes['width'], $attributes['height'] );
			}

			$options[$key] = $title;
		}
		
		$options['full'] = esc_html__( 'Full', 'themesky' );
		return $options;
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 220 ) );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'layout'
            ,array(
				'label' 		=> esc_html__( 'Layout', 'themesky' )
				,'type' 		=> Controls_Manager::CHOOSE
				,'options' 		=> array(
					'grid' 		=> array(
						'title' 	=> esc_html__( 'Grid', 'themesky' )
						,'icon' 	=> 'eicon-gallery-grid'
					)
					,'list'		=> array(
						'title' 	=> esc_html__( 'List', 'themesky' )
						,'icon' 	=> 'eicon-post-list'
					)
					,'masonry'		=> array(
						'title' 	=> esc_html__( 'Masonry', 'themesky' )
						,'icon' 	=> 'eicon-gallery-masonry'
					)
				)
				,'default' 		=> 'grid'
				,'classes' 		=> 'control-choose-big'
			)
        );
		
		$this->add_control(
            'columns'
            ,array(
                'label' 		=> esc_html__( 'Columns', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> '3'
				,'options'		=> array(
									'1'			=> '1'
									,'2'		=> '2'
									,'3'		=> '3'
								)			
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     	=> esc_html__( 'Limit Posts', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 3
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'orderby'
            ,array(
                'label' 		=> esc_html__( 'Order by', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'date'
				,'options'		=> array(
									'none'		=> esc_html__( 'None', 'themesky' )
									,'ID'		=> esc_html__( 'ID', 'themesky' )
									,'date'		=> esc_html__( 'Date', 'themesky' )
									,'name'		=> esc_html__( 'Name', 'themesky' )
									,'title'	=> esc_html__( 'Title', 'themesky' )
								)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'order'
            ,array(
                'label' 		=> esc_html__( 'Order', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'DESC'
				,'options'		=> array(
									'DESC'		=> esc_html__( 'Descending', 'themesky' )
									,'ASC'		=> esc_html__( 'Ascending', 'themesky' )
								)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'categories'
            ,array(
                'label' 		=> esc_html__( 'Categories', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'category'
				)
				,'multiple' 	=> true
				,'sortable' 	=> false
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'show_load_more'
            ,array(
                'label' 		=> esc_html__( 'Load More Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> 	esc_html__( 'Load more items when clicking this button (not available on Slider)', 'themesky' )
            )
        );
		
		$this->add_control(
            'load_more_text'
            ,array(
                'label' 		=> esc_html__( 'Load More Button Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> 'Load More'		
                ,'description' 	=> ''
				,'label_block' 	=> true
				,'condition'	=> array( 'show_load_more' => '1' )
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'show_view_more'
            ,array(
                'label' 		=> esc_html__( 'View More Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> 	esc_html__( 'Link to another page which contains more items. Ex: blog, category, tag', 'themesky' )
            )
        );
		
		$this->add_control(
            'view_more_text'
            ,array(
                'label' 		=> esc_html__( 'View More Button Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> 'View More'		
                ,'description' 	=> ''
                ,'label_block' 	=> true
				,'condition'	=> array( 'show_view_more' => '1' )
            )
        );
		
		$this->add_control(
            'view_more_link'
            ,array(
                'label' 		=> esc_html__( 'View More Button Link', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
				,'label_block' 	=> true
				,'condition'	=> array( 'show_view_more' => '1' )
            )
        );

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'default'
				,'options'		=> array(
									'default'		=> esc_html__( 'Default', 'themesky' )
									,'center'		=> esc_html__( 'Center', 'themesky' )
									,'overlap'		=> esc_html__( 'Overlap', 'themesky' )
									,'overlap-2'	=> esc_html__( 'Overlap 2', 'themesky' )
									,'overlap-3'	=> esc_html__( 'Overlap 3', 'themesky' )
								)		
                ,'description' 	=> ''
				,'condition' 	=> array( 
					'layout!' 	=> array('list') 
				)
            )
        );
		
		$this->add_control(
            'show_title'
            ,array(
                'label' 		=> esc_html__( 'Post Title', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_thumbnail'
            ,array(
                'label' 		=> esc_html__( 'Post Thumbnail', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_categories'
            ,array(
                'label' 		=> esc_html__( 'Post Categories', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_author'
            ,array(
                'label' 		=> esc_html__( 'Post Author', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description'	=> ''
            )
        );
		
		$this->add_control(
            'show_comment'
            ,array(
                'label' 		=> esc_html__( 'Post Comment', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_date'
            ,array(
                'label' 		=> esc_html__( 'Post Date', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_excerpt'
            ,array(
                'label' 		=> esc_html__( 'Post Excerpt', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'excerpt_words'
            ,array(
                'label'     => esc_html__( 'Number of Words in Excerpt', 'themesky' )
                ,'type'     => Controls_Manager::NUMBER
				,'default'  => 36
				,'min'      => 1
				,'condition'=> array( 'show_excerpt' => '1' )
            )
        );
		
		$this->add_control(
            'show_readmore'
            ,array(
                'label' 		=> esc_html__( 'Read More Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )		
                ,'description' 	=> 	esc_html__( 'Show button read more in each post', 'themesky' )
            )
        );
		
		$this->add_control(
            'thumbnail_size'
            ,array(
                'label' 		=> esc_html__( 'Thumbnail Size', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> ''
				,'options'		=> $this->get_image_size_options()	
                ,'description' 	=> ''
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
				,'condition' 	=> array( 
					'layout' 	=> array('grid', 'list') 
				)
            )
        );
		
		$this->add_control(
            'is_slider'
            ,array(
                'label' 		=> esc_html__( 'Enable Slider', 'themesky' )
                ,'type'			=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> ''
            )
        );
		
		$this->add_product_slider_controls_basic();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_responsive_control(
			'items_gap'
			,array(
				'label' => esc_html__( 'Items Gap', 'themesky' )
				,'type' => Controls_Manager::SLIDER
				,'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'default' => array(
					'size' => 30
				)
				,'range' => array(
					'px' => array(
						'min' => 0
						,'max' => 100
					)
				)
				,'description' 	=> esc_html__( 'The spacing between items', 'themesky' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-blogs-wrapper .swiper .item'=> 'padding: calc({{SIZE}}{{UNIT}}/2);'
					,'{{WRAPPER}} .ts-blogs-wrapper .items.swiper' => 'margin: calc(-{{SIZE}}{{UNIT}}/2);'
					,'{{WRAPPER}} .ts-blogs-wrapper .items:not(.swiper),
					{{WRAPPER}} .ts-elementor-lazy-load .placeholder-items' => '--ts-h-gap: {{SIZE}}{{UNIT}}; --ts-v-gap: {{SIZE}}{{UNIT}};'
					,'{{WRAPPER}} .ts-blogs-wrapper:not(.nav-top) :is(.swiper-button-prev,.swiper-button-next)' => 'margin-top: calc({{SIZE}}{{UNIT}}/2)'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_5'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_title_font'
            ,array(
                'label'     	=> esc_html__( 'Heading Title', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_title_style_controls();
		
		
		$this->add_control(
			'ts_hr_3'
			,array(
                'type' 			=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'blog_title_font'
            ,array(
                'label'     	=> esc_html__( 'Blog Title', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'b_title_typography'
				,'selector'			=> '{{WRAPPER}} .ts-blogs .entry-title'
				,'exclude'			=> array('text_decoration', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
			'ts_hr_4'
			,array(
                'type' 			=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'blog_datetime'
            ,array(
                'label'     	=> esc_html__( 'Date Time', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'text_datetime_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#ffffff'
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-blogs[class*="item-overlap"] .item:not(.video):not(.audio) .entry-content .entry-meta-top, 
					{{WRAPPER}} .ts-blogs[class*="item-overlap"] .item:not(.video):not(.audio) .entry-content a, 
					{{WRAPPER}} .ts-blogs[class*="item-overlap"] .item:not(.video):not(.audio) .entry-content a:hover, 
					{{WRAPPER}} .item-overlap-2 .item:not(.video):not(.audio) .entry-content .date-time' => 'color: {{VALUE}} !important'
				)
            )
        );
		
		$this->add_control(
            'text_datetime_bg'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-blogs.item-overlap .item:not(.video):not(.audio) .entry-content .entry-meta-top, 
					{{WRAPPER}} .ts-blogs.item-overlap-2 .item:not(.video):not(.audio) .entry-content .date-time' => 'background: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'			=> 0
			,'title'			=> ''
			,'title_style'		=> 'title-default'
			,'layout'			=> 'grid'
			,'style'			=> 'default'
			,'columns'			=> 2
			,'categories'		=> array()
			,'limit'			=> 9
			,'orderby'			=> 'date'
			,'order'			=> 'DESC'
			,'show_title'		=> 1
			,'show_thumbnail'	=> 1
			,'show_categories'	=> 1
			,'show_author'		=> 0
			,'show_date'		=> 1
			,'show_comment'		=> 0
			,'show_excerpt'		=> 0
			,'show_readmore'	=> 0
			,'thumbnail_size'	=> ''
			,'excerpt_words'	=> 36
			,'is_slider'		=> 1
			,'show_nav'			=> 0
			,'show_dots'		=> 0
			,'auto_play'		=> 0
			,'loop' 			=> 1
			,'show_load_more'	=> 0
			,'load_more_text'	=> 'Load More'
			,'show_view_more'	=> 0
			,'view_more_text'	=> 'View More'
			,'view_more_link'	=> ''
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( !is_numeric($excerpt_words) ){
			$excerpt_words = 20;
		}
		
		$is_masonry = 0;
		if( $layout == 'masonry' ){
			wp_enqueue_script( 'isotope' );
			$is_masonry = 1;
		}
		
		if( $this->lazy_load_placeholder( $settings, 'blog' ) ){
			return;
		}
		
		if( $layout == 'list' ){
			$style = 'default';
		}
		
		$columns = absint($columns);
		if( !in_array($columns, array(1, 2, 3, 4)) ){
			$columns = 2;
		}
		
		$args = array(
			'post_type' 			=> 'post'
			,'post_status' 			=> 'publish'
			,'ignore_sticky_posts' 	=> 1
			,'posts_per_page'		=> $limit
			,'orderby'				=> $orderby
			,'order'				=> $order
			,'tax_query'			=> array()
		);

		if( $categories ){
			$args['tax_query'][] = array(
										'taxonomy' 	=> 'category'
										,'terms' 	=> $categories
										,'field' 	=> 'term_id'
										,'include_children' => false
									);
		}
		
		global $post;
		$posts = new WP_Query($args);
		
		if( $posts->have_posts() ):
			if( $posts->post_count <= 1 ){
				$is_slider = 0;
			}
			if( $is_slider || $posts->max_num_pages == 1 ){
				$show_load_more = 0;
			}
			
			$classes = array();
			$classes[] = 'ts-blogs-wrapper ts-shortcode ts-blogs';
			$classes[] = 'columns-' . $columns;
			$classes[] = 'style-' . $layout;
			$classes[] = 'item-' . $style;
			$classes[] = $title_style;
			
			if( $is_slider ){
				$classes[] = 'ts-slider loading';
				if( $show_nav ){
					$classes[] = 'middle-thumbnail rows-1';
				}
			}
			
			if( $is_masonry ){
				$classes[] = 'ts-masonry loading';
			}
			
			$data_attr = array();
			if( $is_slider ){
				$data_attr[] = 'data-nav="'.$show_nav.'"';
				$data_attr[] = 'data-dots="'.$show_dots.'"';
				$data_attr[] = 'data-autoplay="'.$auto_play.'"';
				$data_attr[] = 'data-loop="'.$loop.'"';
				$data_attr[] = 'data-columns="'.$columns.'"';
			}
			
			if( is_array($categories) ){
				$categories = implode(',', $categories);
			}
			
			$atts = compact('layout', 'columns', 'categories', 'limit', 'orderby', 'order', 'style', 'thumbnail_size'
							,'show_title', 'show_thumbnail', 'show_author', 'show_categories'
							,'show_date', 'show_comment', 'show_excerpt', 'show_readmore', 'excerpt_words'
							,'is_slider', 'show_nav', 'auto_play', 'is_masonry', 'show_load_more');
			?>
			<div class="<?php echo esc_attr(implode(' ', $classes)); ?>" style="--ts-columns: <?php echo esc_attr($columns) ?>" data-atts="<?php echo htmlentities(json_encode($atts)); ?>" <?php echo implode(' ', $data_attr); ?>>
				<?php if( $title ): ?>
				<header class="shortcode-heading-wrapper">
					<h3 class="shortcode-title">
						<?php echo esc_html($title); ?>
					</h3>
					<?php if( $show_view_more && $view_more_text && $view_more_link ): ?>
					<div class="view-more-wrapper">
						<a class="view-more button-text" href="<?php echo esc_url( $view_more_link ); ?>"><?php echo esc_html( $view_more_text ); ?></a>
					</div>
					<?php endif; ?>
				</header>
				<?php endif; ?>
				
				<div class="content-wrapper">
					<div class="blogs items">
						<?php ts_get_blog_items_content($atts, $posts); ?>
					</div>
					
					<?php if( $show_load_more ): ?>
					<div class="load-more-wrapper">
						<a href="#" class="load-more button" data-posts_per_page="<?php echo esc_attr( $limit ); ?>" data-total_pages="<?php echo esc_attr( $posts->max_num_pages ); ?>" data-paged="2"><?php echo esc_html($load_more_text) ?></a>
					</div>
					<?php endif; ?>
				</div>
			</div>
		<?php
		endif;
		wp_reset_postdata();
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Blogs() );