<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Banner extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-banner';
    }
	
	public function get_title(){
        return esc_html__( 'TS Banner', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-image';
	}
	
	protected function register_controls(){
		
		$this->start_controls_section(
            'section_bg'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'img_bg'
            ,array(
                'label' 		=> esc_html__( 'Background Image', 'themesky' )
                ,'type' 		=> Controls_Manager::MEDIA
                ,'default' 		=> array( 
					'id' 		=> ''
					,'url' 		=> '' 
				)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'bg_image_device'
            ,array(
                'label' 		=> esc_html__( 'Background Image Device', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'none'
				,'options'		=> array(
					'none'					=> esc_html__( 'None', 'themesky' )
					,'img-mobile'			=> esc_html__( 'Mobile', 'themesky' )
					,'img-tablet'			=> esc_html__( 'Tablet', 'themesky' )
					,'img-mobile-tablet'	=> esc_html__( 'Mobile & Tablet', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'img_bg_mobile'
            ,array(
                'type' 			=> Controls_Manager::MEDIA
                ,'default' 		=> array( 'id' => '', 'url' => '' )		
                ,'description' 	=> esc_html__( 'Use this image for device. If not selected, it will show image above', 'themesky' )
				,'condition'	=> array( 
					'bg_image_device!' 	=> 'none'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_title'
            ,array(
                'label' 		=> esc_html__( 'Heading', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'top_description'
            ,array(
                'label' 		=> esc_html__( 'Top Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'bottom_description'
            ,array(
                'label' 		=> esc_html__( 'Bottom Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'ts_hr_8'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'link'
            ,array(
                'label'     		=> esc_html__( 'Link', 'themesky' )
                ,'type'     		=> Controls_Manager::URL
				,'default'  		=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
				,'show_external'	=> true
				,'description' 		=> ''
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_layout'
            ,array(
                'label' 	=> esc_html__( 'Layout', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_responsive_control(
			'content_width'
			,array(
				'label' => esc_html__( 'Content Max Width (%)', 'themesky' )
				,'type' => Controls_Manager::NUMBER
				,'min' => 0
				,'max' => 100
				,'step' => 1
				,'default' => 100
				,'selectors' => array(
					'{{WRAPPER}} .box-content' => 'max-width: {{VALUE}}%;'
				)
			)
		);
		
		$this->add_responsive_control(
            'h_align'
            ,array(
                'label' 		=> esc_html__( 'Horizontal Align', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'default' 		=> 'flex-start'
				,'options' 		=> array(
					'flex-start' => array(
						'title' => esc_html__( 'Top', 'themesky' )
						,'icon' => 'eicon-h-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Middle', 'themesky' )
						,'icon' => 'eicon-h-align-center'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Bottom', 'themesky' )
						,'icon' => 'eicon-h-align-right'
					)
				)
				,'description' 	=> ''
				,'prefix_class' => 'h-align-%s'
				,'selectors' => array(
					'{{WRAPPER}} .box-content' => 'align-items: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'v_align'
			,array(
				'label' => esc_html__( 'Vertical Align', 'themesky' )
				,'type' => Controls_Manager::CHOOSE
				,'default' => 'center'
				,'options' => array(
					'flex-start' => array(
						'title' => esc_html__( 'Top', 'themesky' )
						,'icon' => 'eicon-v-align-top'
					)
					,'center' => array(
						'title' => esc_html__( 'Middle', 'themesky' )
						,'icon' => 'eicon-v-align-middle'
					)
					,'flex-end' => array(
						'title' => esc_html__( 'Bottom', 'themesky' )
						,'icon' => 'eicon-v-align-bottom'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .box-content' => 'justify-content: {{VALUE}}'
				)
			)
		);
		
		$this->add_responsive_control(
            'alignment'
            ,array(
                'label' 		=> esc_html__( 'Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .box-content .content-text' => 'text-align: {{VALUE}};'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_3'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_responsive_control(
			'content_margin'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Content Margin', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .box-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'content_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Content Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .box-content .content-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'content_bg'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .box-content .content-text' => 'background: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'min_width'
			,array(
				'label' 		=> esc_html__( 'Min Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 100
						,'max' 	=> 500
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content .content-text' => 'min-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_4'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'banner_sticky'
            ,array(
                'label' 		=> esc_html__( 'Banner Sticky', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'		
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'banner_sticky_top'
			,array(
				'label' 		=> esc_html__( 'Top', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'default' => array(
					'unit' => 'px'
					,'size' => 0
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}}' => 'position: sticky; top: {{SIZE}}{{UNIT}}'
				)
				,'condition'	=> array( 
					'banner_sticky' => array( '1' ) 
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_button'
            ,array(
                'label' 		=> esc_html__( 'Button', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'button_style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'button'
				,'options'		=> array(
					'button'		=> esc_html__( 'Button', 'themesky' )
					,'button-text'	=> esc_html__( 'Text', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'button_text'
            ,array(
                'label'     	=> esc_html__( 'Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'button_position'
            ,array(
                'label' 		=> esc_html__( 'Position', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> '0'
				,'options'		=> array(
					'0'					=> esc_html__( 'Default', 'themesky' )
					,'bottom'			=> esc_html__( 'Bottom', 'themesky' )
					,'diagonal-angle'	=> esc_html__( 'Diagonal Angle', 'themesky' )
				)
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'button_typography'
				,'selector'			=> '{{WRAPPER}} a.button-text, 
										{{WRAPPER}} button.button-text, 
										{{WRAPPER}} .button-text a, 
										{{WRAPPER}} .button-text'
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		
		$this->start_controls_tab(
			'style_normal_tab'
			,array(
				'label' 		=> esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .button,
					{{WRAPPER}} .button-text' => 'color: {{VALUE}}'
					,'{{WRAPPER}} .button-text:before' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#ffffff'
				,'selectors'	=> array(
					'{{WRAPPER}} .button' => 'background: {{VALUE}}'
				)
				,'condition'	=> array( 
					'button_style' => array( 'button' ) 
				)
            )
        );
		
		$this->add_control(
            'button_border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#ffffff'
				,'selectors'	=> array(
					'{{WRAPPER}} .button' => 'border-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'button_style' => array( 'button' ) 
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'style_hover_tab'
			,array(
				'label' 		=> esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_control(
            'button_text_hover'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#ffffff'
				,'selectors'	=> array(
					'{{WRAPPER}} .button:hover,
					{{WRAPPER}} .button-text:hover' => 'color: {{VALUE}}'
					,'{{WRAPPER}} .button-text:hover:before' => 'border-color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'button_background_hover'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .button:hover' => 'background: {{VALUE}}'
				)
				,'condition'	=> array( 
					'button_style' => array( 'button' ) 
				)
            )
        );
		
		$this->add_control(
            'button_border_hover'
            ,array(
                'label'     	=> esc_html__( 'Border Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .button:hover' => 'border-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'button_style' => array( 'button' ) 
				)
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'h_title_font'
            ,array(
                'label'     	=> esc_html__( 'Heading', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'h_text_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .box-content h2' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'h_typography'
				,'selector'			=> '{{WRAPPER}} .box-content h2'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '40'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '44'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_responsive_control(
			'h_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content h2' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_5'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'h_top_description_font'
            ,array(
                'label'     	=> esc_html__( 'Top Description', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            't_description_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .box-content .top-description' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 't_description_typography'
				,'selector'			=> '{{WRAPPER}} .box-content .top-description'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '14'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '20'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_responsive_control(
			't_description_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content .top-description' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_7'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'h_bottom_description_font'
            ,array(
                'label'     	=> esc_html__( 'Bottom Description', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'b_description_color'
            ,array(
                'label'     	=> esc_html__( 'Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .box-content .bottom-description' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'b_description_typography'
				,'selector'			=> '{{WRAPPER}} .box-content .bottom-description'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '16'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '20'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_responsive_control(
			'description_content_width'
			,array(
				'label' 		=> esc_html__( 'Max Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 100
						,'max' 	=> 500
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content .bottom-description' => 'max-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'b_description_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .box-content .bottom-description' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_background_overlay'
            ,array(
                'label' 	=> esc_html__( 'Background Overlay', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'background_overlay_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
            )
        );
		
		$this->add_control(
			'background_overlay_location'
			,array(
				'label' 		=> esc_html__( 'Location', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'default' => array(
					'unit' => '%'
					,'size' => 0
				)
			)
		);
		
		$this->add_control(
            'background_overlay_second_color'
            ,array(
                'label'     	=> esc_html__( 'Background Second Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
            )
        );
		
		$this->add_control(
			'background_overlay_location_2'
			,array(
				'label' 		=> esc_html__( 'Location', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'default' 	=> array(
					'unit' => '%'
					,'size' => 0
				)
			)
		);
		
		$this->add_control(
			'background_overlay_gradient_angle'
			,array(
				'label' 		=> esc_html__( 'Angle', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'default' 		=> array(
					'unit' => 'deg'
					,'size' => 180
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .background-overlay' => 'background-color: transparent; background-image: linear-gradient({{SIZE}}{{UNIT}}, {{background_overlay_color.VALUE}} {{background_overlay_location.SIZE}}{{background_overlay_location.UNIT}}, {{background_overlay_second_color.VALUE}} {{background_overlay_location_2.SIZE}}{{background_overlay_location_2.UNIT}})'
				)
			)
		);
		
		$this->add_responsive_control(
			'background_overlay_opacity'
			,array(
				'label' 	=> esc_html__( 'Opacity', 'themesky' )
				,'type' 	=> Controls_Manager::SLIDER
				,'devices' 	=> array( 
					'desktop'
					,'tablet' 
					,'mobile' 
				)
				,'range' 	=> array(
					'px' 	=> array(
							'min' 	=> 0
							,'max' 	=> 1
					)
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .background-overlay' => 'opacity: {{SIZE}}'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_effect'
            ,array(
                'label' 	=> esc_html__( 'Motion Effect', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
			'ts_hr_6'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'style_effect'
            ,array(
                'label' 		=> esc_html__( 'Entrance Animation', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'eff-zoom-in'
				,'options'		=> array(									
									'eff-grow-rotate' 			=> esc_html__('Grow Rotate', 'themesky')
									,'eff-zoom-in'				=> esc_html__('Zoom in', 'themesky')
									,'no-effect' 				=> esc_html__('None', 'themesky')
								)
                ,'description' 	=> ''
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'opacity_hover'
            ,array(
                'label'     	=> esc_html__( 'Opacity Hover', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
				,'default'  	=> '0'
				,'options'		=> array(
					'1'		=> esc_html__( 'Yes', 'themesky' )
					,'0'	=> esc_html__( 'No', 'themesky' )
				)
            )
        );
		
		$this->add_control(
            'background_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#ffffff'
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-banner' => 'background-color: {{VALUE}}'
					,'{{WRAPPER}} .ts-banner:hover img' => 'opacity: 0.5'
				)
				,'condition'	=> array( 
					'opacity_hover' => array( '1' ) 
				)
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'img_bg'							=> array( 'id' => '', 'url' => '' )
			,'img_bg_mobile'					=> array( 'id' => '', 'url' => '' )
			,'bg_image_device'					=> 'none'
			,'heading_title'					=> ''
			,'description'						=> ''
			,'b_description'					=> ''
			,'button_text'						=> ''
			,'button_position'					=> '0'
			,'link' 							=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
			,'style_effect'						=> 'eff-zoom-in'
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		$link_attr = '#';
		$link_attr = $this->generate_link_attributes( $link );
		
		$classes = array();
		$classes[] = $style_effect;
		if( $button_position ){
			$classes[] = 'margin-button-auto';
			$classes[] = 'button-'.$button_position;
		}
		if( $bg_image_device != 'none' ){
			$classes[] = $bg_image_device;
		}
		
		$allow_tags = array(
			'a'			=> array('href' => array(),'title' => array(),'style' => array())
			,'span'		=> array('class' => array(),'style' => array())
			,'div'		=> array('class' => array(),'style' => array())
			,'strong'	=> array('class' => array(),'style' => array())
			,'em'		=> array('class' => array(),'style' => array())
			,'br'		=> array('class' => array(),'style' => array())
		);
		?>
		<div class="ts-banner <?php echo esc_attr( implode(' ', $classes) ); ?>">
			<div class="banner-wrapper">
			
				<?php if( $link_attr && !$button_text ): ?>
				<a class="banner-link" <?php echo implode(' ', $link_attr); ?>></a>
				<?php endif;?>
				
				<div class="background-overlay"></div>
				
				<div class="banner-bg">
				<?php 
					if( !empty( $img_bg_mobile['id'] ) && $bg_image_device != 'none' ){
						echo wp_get_attachment_image($img_bg_mobile['id'], 'full', 0, array('class' => 'bg-image mobile-banner'));
					}
					echo wp_get_attachment_image($img_bg['id'], 'full', 0, array('class' => 'bg-image main-banner'));
				?>
				</div>
					
				<div class="box-content">
					<div class="content-text">
				
						<?php if( $top_description ): ?>				
							<div class="top-description"><?php echo wp_kses( $top_description, $allow_tags ); ?></div>
						<?php endif; ?>
						
						<?php if( $heading_title ): ?>				
							<h2><?php echo wp_kses( $heading_title, $allow_tags ); ?></h2>
						<?php endif; ?>
						
						<?php if( $bottom_description ): ?>				
							<div class="bottom-description"><?php echo wp_kses( $bottom_description, $allow_tags ); ?></div>
						<?php endif; ?>
						
						<?php if( $button_text ):?>
							<div class="ts-banner-button">
								<a class="<?php echo $button_style ?>" <?php echo implode(' ', $link_attr); ?>><?php echo esc_html($button_text) ?></a>
							</div>
						<?php endif; ?>
					</div>
				</div>
				
			</div>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Banner() );