<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Testimonial extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-testimonial';
    }
	
	public function get_title(){
        return esc_html__( 'TS Testimonial', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-testimonial';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 50, 'thumb-label' => esc_html__( 'Lazy Load - Content Height', 'themesky' ) ) );
		
		$this->add_control(
            'categories'
            ,array(
                'label' 		=> esc_html__( 'Categories', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'ts_testimonial_cat'
				)
				,'multiple' 	=> true
				,'sortable' 	=> false
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'ids'
            ,array(
                'label' 		=> esc_html__( 'Specific testimonials', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'post'
					,'name'		=> 'ts_testimonial'
				)
				,'multiple' 	=> true
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'columns'
            ,array(
                'label' => esc_html__( 'Columns', 'themesky' )
                ,'type' => Controls_Manager::SELECT
                ,'default' => '1'
				,'options'	=>array(
							'1'		=> esc_html__( '1', 'themesky' )
							,'2'	=> esc_html__( '2', 'themesky' )
							,'3'	=> esc_html__( '3', 'themesky' )
							)			
                ,'description' => ''
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     => esc_html__( 'Limit', 'themesky' )
                ,'type'     => Controls_Manager::NUMBER
				,'default'  => 3
				,'min'      => 1
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'style-1'
				,'options'		=> array(
									'style-1'			=> 'Style 1'
									,'style-2'			=> 'Style 2'
								)			
            )
        );
		
		$this->add_control(
            'show_avatar'
            ,array(
                'label' 		=> esc_html__( 'Avatar', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_name'
            ,array(
                'label' 		=> esc_html__( 'Name', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_byline'
            ,array(
                'label' 		=> esc_html__( 'Byline', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_rating'
            ,array(
                'label' 		=> esc_html__( 'Rating', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_quote_icon'
            ,array(
                'label' 		=> esc_html__( 'Quote Icon', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'excerpt_words'
            ,array(
                'label'     => esc_html__( 'Number of words in excerpt', 'themesky' )
                ,'type'     => Controls_Manager::NUMBER
				,'default'  => 60
				,'min'      => '-1'
				,'description'	=> esc_html__( 'Input -1 to show all content', 'themesky' )
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'ts_alignment'
            ,array(
                'label' 		=> esc_html__( 'Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'prefix_class' => 'ts-align'
				,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'quote_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Blockquote Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-testimonial-wrapper blockquote,
					{{WRAPPER}} .ts-elementor-lazy-load.type-testimonial .placeholder-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'quote_width'
			,array(
				'label' 		=> esc_html__( 'Max Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 1200
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-testimonial-wrapper blockquote' => 'max-width: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'content_bg_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} blockquote,
					{{WRAPPER}} .placeholder-item' => 'background-color: {{VALUE}}'
				)
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'is_slider'
            ,array(
                'label' 		=> esc_html__( 'Enable slider', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )			
                ,'description' => ''
            )
        );
		
		$this->add_product_slider_controls_basic();
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'name_title'
            ,array(
                'label'     	=> esc_html__( 'Name', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'name_typography'
				,'selector'			=> '{{WRAPPER}} .testimonial-meta .meta-right .author'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '18'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '22'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_decoration', 'text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
            'name_color'
            ,array(
                'label'     	=> esc_html__( 'Name Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .testimonial-meta .meta-right' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_title'
            ,array(
                'label'     	=> esc_html__( 'Quote Text', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'quote_typography'
				,'selector'			=> '{{WRAPPER}} .ts-testimonial-wrapper blockquote'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '20'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '36'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_decoration', 'text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
            'quote_color'
            ,array(
                'label'     	=> esc_html__( 'Quote Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} blockquote .content,
					{{WRAPPER}} .testimonial-meta .meta-right .role,
					{{WRAPPER}} .swiper-button-next, 
					{{WRAPPER}} .swiper-button-prev' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_responsive_control(
			'quote_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 50
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .testimonial-meta' => 'margin-top: {{SIZE}}{{UNIT}};'
				)
			)
		);
	
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'				=> 0
			,'style'				=> 'style-1'
			,'categories'			=> array()
			,'columns'				=> 1
			,'limit'				=> 3
			,'ids'					=> array()
			,'show_avatar'			=> 1
			,'show_name'			=> 1
			,'show_byline'			=> 0
			,'show_rating'			=> 1
			,'show_quote_icon'		=> 1
			,'excerpt_words'		=> 60
			,'is_slider'			=> 1
			,'show_nav'				=> 0
			,'show_dots'			=> 0
			,'auto_play'			=> 0
			,'loop' 				=> 1
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		if( $this->lazy_load_placeholder( $settings, 'testimonial' ) ){
			return;
		}
		
		extract( $settings );
		
		$classes = array();
		$classes[] = 'columns-'.$columns;
		$classes[] = $style;
		if( !$show_quote_icon ){
			$classes[] = 'hide-quote-icon';
		}
		if($is_slider){
			$classes[] = 'ts-slider';
		}
		
		$data_attr = array();
		if( $is_slider ){
			$data_attr[] = 'data-columns="'.$columns.'"';
			$data_attr[] = 'data-nav="'.$show_nav.'"';
			$data_attr[] = 'data-dots="'.$show_dots.'"';
			$data_attr[] = 'data-autoplay="'.$auto_play.'"';
			$data_attr[] = 'data-loop="'.$loop.'"';
		}

		global $post, $ts_testimonials;
		
		$args = array(
				'post_type'				=> 'ts_testimonial'
				,'post_status'			=> 'publish'
				,'posts_per_page' 		=> $limit
				,'orderby' 				=> 'date'
				,'order' 				=> 'desc'
			);
		
		if( is_array($categories) && count($categories) > 0 ){
			$args['tax_query'] = array(
									array(
										'taxonomy' 			=> 'ts_testimonial_cat'
										,'terms' 			=> $categories
										,'field' 			=> 'term_id'
										,'include_children' => false
									)
								);
		}
		
		if( is_array($ids) && count($ids) > 0 ){
			$args['post__in'] = $ids;
			$args['orderby'] = 'post__in';
		}
		
		$testimonials = new WP_Query($args);
		
		if( $testimonials->have_posts() ){
			if( isset($testimonials->post_count) && $testimonials->post_count <= 1 ){
				$is_slider = false;
			}
			?>
			<div class="ts-testimonial-wrapper ts-shortcode <?php echo esc_attr(implode(' ', $classes)); ?>" style="--ts-columns: <?php echo esc_attr($columns) ?>" <?php echo implode(' ', $data_attr); ?>>
		
				<div class="items <?php echo ($is_slider)?'loading':'' ?>">
				<?php
				while( $testimonials->have_posts() ){
					$testimonials->the_post();			
					
					if( $excerpt_words != -1 ){		
						if( function_exists('emall_the_excerpt_max_words') ){
							$content = emall_the_excerpt_max_words($excerpt_words, $post, true, '', false);
						}
						else{
							$content = wp_trim_words( $post->post_content, $excerpt_words );
						}
					} 

					$byline = get_post_meta($post->ID, 'ts_byline', true);
					$url = get_post_meta($post->ID, 'ts_url', true);
					if( $url == '' ){
						$url = '#';
					}
					$rating = get_post_meta($post->ID, 'ts_rating', true);
					$rating_percent = '0';
					if( $rating != '-1' && $rating != '' ){
						$rating_percent = $rating * 100 / 5;
					}
					
					$show_item_avatar = $show_avatar;
					if( $show_item_avatar ){
						$gravatar_email = get_post_meta($post->ID, 'ts_gravatar_email', true);
						if( !has_post_thumbnail() && ($gravatar_email == '' || !is_email($gravatar_email)) ){
							$show_item_avatar = false;
						}
					}
					
					?>
					<div class="item">
						<blockquote>
							
							<?php if( $show_rating && $rating != '-1' && $rating != '' && $style == 'style-2'): ?>
								<div class="rating" title="<?php printf( esc_html__('Rated %s out of 5', 'themesky'), $rating ); ?>">
									<span style="width: <?php echo $rating_percent . '%'; ?>"><?php printf( esc_html__('Rated %s out of 5', 'themesky'), $rating ); ?></span>
								</div>
								<?php endif; ?>
								
							<div class="content">
								<?php if( $excerpt_words != -1 ): ?> 
									<?php echo esc_html($content); ?>
								<?php else:
									the_content();		
								endif; ?>
							</div>
							
							<?php if( $show_item_avatar || $show_name || ($show_byline && $byline != '') ): ?>
							<div class="testimonial-meta <?php echo !$show_item_avatar?'no-avatar':'' ?>">
							
								<?php if( $show_item_avatar ): ?>
								<div class="image">
									<?php echo $ts_testimonials->get_image($post->ID); ?>
								</div>
								<?php endif; ?>
								
								<?php if( ($show_rating && $rating != '-1' && $rating != '' && $style == 'style-1') || $show_name || ( $show_byline && $byline != '' ) ): ?>
								<div class="meta-right">
									<?php if( $show_rating && $rating != '-1' && $rating != '' && $style == 'style-1'): ?>
									<div class="rating" title="<?php printf( esc_html__('Rated %s out of 5', 'themesky'), $rating ); ?>">
										<span style="width: <?php echo $rating_percent . '%'; ?>"><?php printf( esc_html__('Rated %s out of 5', 'themesky'), $rating ); ?></span>
									</div>
									<?php endif; ?>
									
									<?php if( $show_name ): ?>
									<span class="author">
										<a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo get_the_title($post->ID); ?></a>
									</span>
									<?php endif; ?>
									
									<?php if( $show_byline && $byline != '' ): ?>
									<span class="role"><?php echo esc_html($byline); ?></span>
									<?php endif; ?>
								</div>
								<?php endif; ?>
								
							</div>
							<?php endif; ?>
							
							
						</blockquote>
					</div>
					<?php
				}
				?>
				</div>
			</div>
			<?php
		}
		
		wp_reset_postdata();
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Testimonial() );