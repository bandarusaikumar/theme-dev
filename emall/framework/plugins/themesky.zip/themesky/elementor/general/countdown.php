<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Countdown extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-countdown';
    }
	
	public function get_title(){
        return esc_html__( 'TS Countdown', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-countdown';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'default'
				,'options'		=> array(
									'default'			=> esc_html__( 'Default', 'themesky' )
									,'background'		=> esc_html__( 'Background', 'themesky' )
									,'background-2'		=> esc_html__( 'Background 2', 'themesky' )
								)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'date'
            ,array(
                'label' 			=> esc_html__( 'Date', 'themesky' )
                ,'type' 			=> Controls_Manager::DATE_TIME
                ,'default' 			=> date( 'Y-m-d', strtotime('+1 day') )
            )
        );
		
		$this->add_responsive_control(
			'gap'
			,array(
				'label' 		=> esc_html__( 'Gap', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .counter-wrapper' => 'gap: {{SIZE}}{{UNIT}};'
					,'{{WRAPPER}} .dots-inside .counter-wrapper > *' => 'column-gap: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'bg_color'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .counter-wrapper > div' => 'background: {{VALUE}};'
					,'{{WRAPPER}} .counter-wrapper > span' => 'display: none'
				)
				,'condition' 	=> array( 
					'style' 	=> array('background') 
				)
            )
        );
		$this->add_control(
            'bg_color_2'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .counter-wrapper > div .number-wrapper' => 'background: {{VALUE}};'
				)
				,'condition' 	=> array( 
					'style' 	=> array('background-2') 
				)
            )
        );
		
		$this->add_responsive_control(
			'time_width_2'
			,array(
				'label' 		=> esc_html__( 'Min Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 50
						,'max' 	=> 150
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .counter-wrapper > div .number-wrapper' => 'min-width: {{SIZE}}{{UNIT}};min-height: {{SIZE}}{{UNIT}}'
				)
				,'condition' 	=> array( 
					'style' 	=> array('background-2') 
				)
			)
		);
		
		$this->add_responsive_control(
			'time_width'
			,array(
				'label' 		=> esc_html__( 'Min Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 50
						,'max' 	=> 150
					)
				)
				,'size_units' 	=> array( 'px' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .counter-wrapper > div' => 'min-width: {{SIZE}}{{UNIT}};min-height: {{SIZE}}{{UNIT}}; display: flex;flex-direction:column; justify-content:center;'
				)
				,'condition' 	=> array( 
					'style' 	=> array('background') 
				)
			)
		);
		
		$this->add_control(
            'number_font'
            ,array(
                'label'     	=> esc_html__( 'Number', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'number_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .counter-wrapper > div' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 	=> esc_html__( 'Typography', 'themesky' )
				,'name' 	=> 'number_typography'
				,'selector'	=> '{{WRAPPER}} .counter-wrapper > div'
				,'fields_options'	=> array(
					'font_size'	=> array(
						'default'	=> array(
							'size' 	=> '30'
							,'unit' => 'px'
						)
						,'size_units' => array( 'px', 'em', 'rem', 'vw' )
					)
				)
				,'exclude'	=> array( 'text_decoration', 'letter_spacing', 'word_spacing')
			)
		);
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 			=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'times_font'
            ,array(
                'label'     	=> esc_html__( 'Times', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'times_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .counter-wrapper .ref-wrapper,
					.counter-wrapper > span' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 	=> esc_html__( 'Typography', 'themesky' )
				,'name' 	=> 'times_typography'
				,'selector'	=> '{{WRAPPER}} .counter-wrapper .ref-wrapper'
				,'fields_options'	=> array(
					'font_size'	=> array(
						'default'	=> array(
							'size' 	=> '14'
							,'unit' => 'px'
						)
						,'size_units' => array( 'px', 'em', 'rem', 'vw' )
					)
				)
				,'exclude'	=> array( 'text_decoration', 'letter_spacing', 'word_spacing')
			)
		);
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 			=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'dots_font'
            ,array(
                'label'     	=> esc_html__( 'Dots', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'dots_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .counter-wrapper .dots' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 	=> esc_html__( 'Typography', 'themesky' )
				,'name' 	=> 'dots_typography'
				,'selector'	=> '{{WRAPPER}} .counter-wrapper .dots'
				,'fields_options'	=> array(
					'font_size'	=> array(
						'default'	=> array(
							'size' 	=> '30'
							,'unit' => 'px'
						)
						,'size_units' => array( 'px', 'em', 'rem', 'vw' )
					)
				)
				,'exclude'	=> array( 'text_decoration', 'letter_spacing', 'word_spacing')
			)
		);
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		if( empty($settings['date']) ){
			return;
		}
		
		$time = strtotime($settings['date']);
		
		if( $time === false ){
			return;
		}
		
		$current_time = current_time('timestamp');
		
		if( $time < $current_time ){
			return;
		}
		
		$settings['seconds'] = $time - $current_time;
		$settings['title']	= 0;
		
		if( $settings['style'] == 'default' || $settings['style'] == 'background-2' ){
			$settings['style'] = 'dots-inside';
		}
		else{
			$settings['style'] = 'no-dots';
		}
		
		ts_countdown( $settings );
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Countdown() );