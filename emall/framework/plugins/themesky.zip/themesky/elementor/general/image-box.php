<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Image_Box extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-image-box';
    }
	
	public function get_title(){
        return esc_html__( 'TS Image Box', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-image-box';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'image'
            ,array(
                'label' 		=> esc_html__( 'Choose Image', 'themesky' )
                ,'type' 		=> Controls_Manager::MEDIA
                ,'default' 		=> array( 
					'id' 		=> ''
					,'url' 		=> '' 
				)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'title_text'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'description_text'
            ,array(
                'label' 		=> esc_html__( 'Description', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXTAREA
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'button_text'
            ,array(
                'label' 		=> esc_html__( 'Button Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''	
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'button_style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'button'
				,'options'		=> array(
					'button'			=> esc_html__( 'Button', 'themesky' )
					,'button-text'		=> esc_html__( 'Text', 'themesky' )
					,'button-text-2'	=> esc_html__( 'Text Line', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'link'
            ,array(
                'label'     		=> esc_html__( 'Link', 'themesky' )
                ,'type'     		=> Controls_Manager::URL
				,'default'  		=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
				,'show_external'	=> true
				,'description' 		=> ''
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_style_box'
			,array(
				'label'  => esc_html__( 'Box', 'themesky' )
				,'tab'   => Controls_Manager::TAB_STYLE
			)
		);
		
		$this->add_control(
			'text_align'
			,array(
				'label' 	=> esc_html__( 'Alignment', 'themesky' )
				,'type' 	=> Controls_Manager::CHOOSE
				,'options' 	=> array(
					'left'	=> array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' 	=> array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' 	=> array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-wrapper .elementor-image-box-content' => 'text-align: {{VALUE}};'
				)
				,'prefix_class' => 'align-'
			)
		);
		
		$this->add_responsive_control(
			'content_width'
			,array(
				'label' => esc_html__( 'Content Max Width (%)', 'themesky' )
				,'type' => Controls_Manager::NUMBER
				,'min' => 0
				,'max' => 100
				,'step' => 1
				,'default' => 100
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-content' => 'max-width: {{VALUE}}%;'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_3'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_responsive_control(
			'image_space'
			,array(
				'label' 		=> esc_html__( 'Image Spacing', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'default' 		=> array(
					'size' => 30
				)
				,'range' => array(
					'px' => array(
						'max' => 100
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-wrapper' => 'gap: {{SIZE}}{{UNIT}};'
					,'(mobile){{WRAPPER}} .elementor-image-box-wrapper' => 'gap: {{SIZE}}{{UNIT}};'
				)
				,'condition' => array(
					'image[url]!' => ''
				)
			)
		);
		
		$this->add_responsive_control(
			'title_bottom_space'
			,array(
				'label' 		=> esc_html__( 'Title Spacing', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'size_units' 	=> array( 'px', 'em', 'rem', 'custom' )
				,'range' => array(
					'px' => array(
						'max' 	=> 100
					)
					,'em' => array(
						'min' 	=> 0
						,'max' 	=> 10
					)
					,'rem' => array(
						'min' 	=> 0
						,'max' 	=> 10
					)
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .elementor-image-box-title' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'description_bottom_space'
			,array(
				'label' 		=> esc_html__( 'Description Spacing', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'size_units' 	=> array( 'px', 'em', 'rem', 'custom' )
				,'range' => array(
					'px' => array(
						'max' 	=> 100
					)
					,'em' => array(
						'min' 	=> 0
						,'max' 	=> 10
					)
					,'rem' => array(
						'min' 	=> 0
						,'max' 	=> 10
					)
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .elementor-image-box-description' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_responsive_control(
			'button_bottom_space'
			,array(
				'label' 		=> esc_html__( 'Button Spacing', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'size_units' 	=> array( 'px', 'em', 'rem', 'custom' )
				,'range' => array(
					'px' => array(
						'max' 	=> 100
					)
					,'em' => array(
						'min' 	=> 0
						,'max' 	=> 10
					)
					,'rem' => array(
						'min' 	=> 0
						,'max' 	=> 10
					)
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} a.button-text-2' => 'padding-bottom: {{SIZE}}{{UNIT}};'
				)
				,'condition'	=> array( 
					'button_style' 	=> 'button-text-2'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_6'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'content_position'
            ,array(
                'label' 		=> esc_html__( 'Content Position', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> ''
				,'options'		=> array(
					''			=> esc_html__( 'Default', 'themesky' )
					,'absolute'	=> esc_html__( 'Absolute', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'content_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Content Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
				,'condition'	=> array( 
					'content_position' 	=> 'absolute'
				)
			)
		);
		
		$this->add_control(
            'content_bg'
            ,array(
                'label'     	=> esc_html__( 'Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .elementor-image-box-content' => 'background: {{VALUE}}'
				)
				,'condition'	=> array( 
					'content_position' 	=> 'absolute'
				)
            )
        );
		
		$this->add_responsive_control(
			'min_width'
			,array(
				'label' 		=> esc_html__( 'Min Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 100
						,'max' 	=> 500
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .elementor-image-box-content' => 'min-width: {{SIZE}}{{UNIT}};'
				)
				,'condition'	=> array( 
					'content_position' 	=> 'absolute'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_style_image'
			,array(
				'label' 		=> esc_html__( 'Image', 'themesky' )
				,'tab'   		=> Controls_Manager::TAB_STYLE
				,'condition' 	=> array(
					'image[url]!' => ''
				)
			)
		);
		
		$this->start_controls_tabs( 'image_effects' );
		
		$this->start_controls_tab(
			'normal'
			,array(
				'label' => esc_html__( 'Normal', 'themesky' )
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Css_Filter::get_type()
			,array(
				'name' 		=> 'css_filters'
				,'selector' => '{{WRAPPER}} .elementor-image-box-img img'
			)
		);
		
		$this->add_control(
			'image_opacity'
			,array(
				'label' => esc_html__( 'Opacity', 'themesky' )
				,'type' => Controls_Manager::SLIDER
				,'range' => array(
					'px' => array(
						'max' 	=> 1
						,'min' 	=> 0.10
						,'step' => 0.01
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-img img' => 'opacity: {{SIZE}};'
				)
			)
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'hover'
			,array(
				'label' => esc_html__( 'Hover', 'themesky' )
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Css_Filter::get_type()
			,array(
				'name' 		=> 'css_filters_hover'
				,'selector' => '{{WRAPPER}}:hover .elementor-image-box-img img'
			)
		);
		
		$this->add_control(
			'image_opacity_hover'
			,array(
				'label' => esc_html__( 'Opacity', 'themesky' )
				,'type' => Controls_Manager::SLIDER
				,'range' => array(
					'px' => array(
						'max' 	=> 1
						,'min' 	=> 0.10
						,'step' => 0.01
					)
				)
				,'selectors' => array(
					'{{WRAPPER}}:hover .elementor-image-box-img img' => 'opacity: {{SIZE}};'
				)
			)
		);
		
		$this->add_control(
			'background_hover_transition'
			,array(
				'label' => esc_html__( 'Transition Duration (s)', 'themesky' )
				,'type' => Controls_Manager::SLIDER
				,'default' => array(
					'size' => 0.3
				)
				,'range' => array(
					'px' => array(
						'min'   => 0
						,'max'  => 3
						,'step' => 0.1
					)
				)
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-img img' => 'transition-duration: {{SIZE}}s'
				)
			)
		);
		
		$this->add_control(
			'hover_animation'
			,array(
				'label' => esc_html__( 'Hover Animation', 'themesky' )
				,'type' => Controls_Manager::HOVER_ANIMATION
			)
		);
		
		$this->add_control(
            'icon_size'
            ,array(
                'label' 		=> esc_html__( 'Icon Size', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'normal'
				,'options'		=> array(
					'normal'					=> esc_html__( 'Normal', 'themesky' )
					,'icon-small'				=> esc_html__( 'Small', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_control(
			'ts_hr_8'
			,array(
                'type' 			=> Controls_Manager::DIVIDER
				,'condition'	=> array( 
					'content_position!' => 'absolute'
				)
            )
		);
		
		$this->add_responsive_control(
            'image_position'
            ,array(
				'label' 		=> esc_html__( 'Image Position', 'themesky' )
				,'type' 		=> Controls_Manager::CHOOSE
				,'options' 		=> array(
					'top' 		=> array(
						'title' 	=> esc_html__( 'Top', 'themesky' )
						,'icon' 	=> 'eicon-flex eicon-v-align-top'
					)
					,'bottom'		=> array(
						'title' 	=> esc_html__( 'Bottom', 'themesky' )
						,'icon' 	=> 'eicon-flex eicon-v-align-bottom'
					)
				)
				,'default' 				=> 'start'
				,'selectors_dictionary' => array(
							'top' => '-99999'
							,'bottom' => '99999'
				)
				,'selectors' 	=> array(
					'{{WRAPPER}} .elementor-image-box-img' => 'order: {{VALUE}};'
				)
				,'condition'	=> array( 
					'content_position!' => 'absolute'
				)
			)
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_style_content'
			,array(
				'label'  => esc_html__( 'Content', 'themesky' )
				,'tab'   => Controls_Manager::TAB_STYLE
			)
		);
		
		$this->add_control(
			'ts_hr_4'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
			'heading_title'
			,array(
				'label' 		=> esc_html__( 'Title', 'themesky' )
				,'type' 		=> Controls_Manager::HEADING
			)
		);
		
		$this->add_control(
			'title_color'
			,array(
				'label' 	=> esc_html__( 'Color', 'themesky' )
				,'type' 	=> Controls_Manager::COLOR
				,'default' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-title' => 'color: {{VALUE}};'
				)
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'name' 		=> 'title_typography'
				,'selector' => '{{WRAPPER}} .elementor-image-box-title'
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
			'ts_hr_5'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
			'heading_description'
			,array(
				'label' 		=> esc_html__( 'Description', 'themesky' )
				,'type' 		=> Controls_Manager::HEADING
			)
		);
		
		$this->add_control(
			'description_color'
			,array(
				'label' 	=> esc_html__( 'Color', 'themesky' )
				,'type' 	=> Controls_Manager::COLOR
				,'default' 	=> ''
				,'selectors' => array(
					'{{WRAPPER}} .elementor-image-box-description' => 'color: {{VALUE}};'
				)
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'name' 		=> 'description_typography'
				,'selector' => '{{WRAPPER}} .elementor-image-box-description'
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
			'ts_hr_7'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
				,'condition'	=> array( 
					'button_style' 	=> array('button-text', 'button-text-2') 
				)
            )
		);
		
		$this->add_control(
			'heading_button'
			,array(
				'label' 		=> esc_html__( 'Button', 'themesky' )
				,'type' 		=> Controls_Manager::HEADING
				,'condition'	=> array( 
					'button_style' 	=> array('button-text', 'button-text-2') 
				)
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Text Typography', 'themesky' )
				,'name' 		=> 'button_typography'
				,'selector' => '{{WRAPPER}} .button-text, {{WRAPPER}} .button-text-2'
				,'condition'	=> array( 
					'button_style' 	=> array('button-text', 'button-text-2') 
				)
				,'exclude'	=> array('text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Icon Typography', 'themesky' )
				,'name' 		=> 'button_icon_typography'
				,'selector' => '{{WRAPPER}} .button-text-2:after'
				,'condition'	=> array( 
					'button_style' 	=> 'button-text-2'
				)
				,'exclude'	=> array('letter-spacing','line-height','text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'image'				=> array( 'url' => '' )
			,'content_position'	=> ''
			,'title_text'		=> ''
			,'description_text'	=> ''
			,'button_text'		=> ''
			,'button_style'		=> 'button-text'
			,'icon_size'		=> 'normal'
			,'link'				=> array()
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( empty($image['url']) ){
			return;
		}
		
		if( !$title_text && !$description_text && !$button_text ){
			return;
		}
		
		$link_attr = $this->generate_link_attributes( $link );
		$classes = array();
		if( $content_position ){
			$classes[] = 'content-absolute';
		}
		if( $icon_size != 'normal' ){
			$classes[] = $icon_size;
		}
		?>
		<div class="ts-image-box-wrapper elementor-image-box-wrapper <?php echo esc_attr( implode(' ', $classes) ); ?>">
			<figure class="elementor-image-box-img">
			<?php
				if( $link_attr ){
					echo '<a ' . implode(' ', $link_attr) . '>';
				}
				echo wp_kses_post( \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'full', 'image' ) );
				if( $link_attr ){
					echo '</a>';
				}
			?>
			</figure>
			<div class="elementor-image-box-content">
				<?php
				if( $description_text && $content_position ){
					echo '<p class="elementor-image-box-description">' . esc_html($description_text) . '</p>';
				}
				if( $title_text ){
					$title_html = $title_text;
					if( $link_attr ){
						$title_html = '<a ' . implode(' ', $link_attr) . '>' . esc_html($title_html) . '</a>';
					}
					echo '<h3 class="elementor-image-box-title">' . $title_html . '</h3>';
				}
				
				if( $description_text && !$content_position ){
					echo '<p class="elementor-image-box-description">' . esc_html($description_text) . '</p>';
				}
				if( $button_text ){
					echo '<a '. implode(' ', $link_attr) .' class="'. $button_style .'">' . esc_html($button_text) . '</a>';
				}
				?>
			</div>
		</div>
		<?php
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Image_Box() );