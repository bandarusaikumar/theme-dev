<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Image_Compare extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-image-compare';
    }
	
	public function get_title(){
        return esc_html__( 'TS Image Compare', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'general' );
    }
	
	public function get_icon(){
		return 'eicon-image-before-after';
	}
	
	public function get_script_depends(){
		if( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ){
			return array('slick-image-compare');
		}
		return array();
	}
	
	public function get_style_depends(){
		if( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ){
			return array('slick-image-compare');
		}
		return array();
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'before_image'
            ,array(
                'label' 		=> esc_html__( 'Before Image', 'themesky' )
                ,'type' 		=> Controls_Manager::MEDIA
                ,'default' 		=> array( 
					'id' 		=> ''
					,'url' 		=> '' 
				)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'after_image'
            ,array(
                'label' 		=> esc_html__( 'After Image', 'themesky' )
                ,'type' 		=> Controls_Manager::MEDIA
                ,'default' 		=> array( 
					'id' 		=> ''
					,'url' 		=> '' 
				)		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'before_label'
            ,array(
                'label' 		=> esc_html__( 'Before Label', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'after_label'
            ,array(
                'label' 		=> esc_html__( 'After Label', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'before_image'		=> array( 'url' => '' )
			,'after_image'		=> array( 'url' => '' )
			,'before_label'		=> ''
			,'after_label'		=> ''
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if( empty($before_image['url']) || empty($after_image['url']) ){
			return;
		}
		
		add_action('wp_footer', array($this, 'ts_render_css'));
		wp_enqueue_script('slick-image-compare');
		
		$unique_id = 'ts-image-compare-' . mt_rand(0, 10000);
		?>
		<div class="ts-image-compare loading" id="<?php echo esc_attr( $unique_id ); ?>" data-beforelabel="<?php echo esc_attr($before_label) ?>" data-afterlabel="<?php echo esc_attr($after_label) ?>">
		<?php 
			$this->ts_image_html( $before_image );
			$this->ts_image_html( $after_image );
		?>
		</div>
		<?php
	}
	
	function ts_render_css(){
		wp_enqueue_style('slick-image-compare');
	}
	
	function ts_image_html( $image ){
		if( !empty($image['id']) ){
			echo wp_get_attachment_image( $image['id'], 'full' );
		}
		else{
		?>
			<img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php esc_attr_e('Image Compare', 'themesky'); ?>" loading="lazy" />
		<?php
		}
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Image_Compare() );