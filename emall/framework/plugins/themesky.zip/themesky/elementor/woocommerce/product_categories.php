<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Product_Categories extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-product-categories';
    }
	
	public function get_title(){
        return esc_html__( 'TS Product Categories', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-product-categories';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 230 ) );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'columns'
            ,array(
                'label'     	=> esc_html__( 'Columns', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 6
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     	=> esc_html__( 'Limit', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 6
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'parent'
            ,array(
                'label' 		=> esc_html__( 'Parent', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> false
				,'sortable' 	=> false
				,'label_block' 	=> true
				,'description' 	=> esc_html__( 'Get direct children of this category', 'themesky' )
				,'condition'	=> array( 'first_level!' => '1' )
            )
        );
		
		$this->add_control(
            'child_of'
            ,array(
                'label' 		=> esc_html__( 'Child of', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> false
				,'sortable' 	=> false
				,'label_block' 	=> true
				,'description' 	=> esc_html__( 'Get all descendents of this category', 'themesky' )
				,'condition'	=> array( 'first_level!' => '1' )
            )
        );
		
		$this->add_control(
            'ids'
            ,array(
                'label' 		=> esc_html__( 'Specific categories', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> true
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'hide_empty'
            ,array(
                'label' 		=> esc_html__( 'Hide empty product categories', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )			
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'first_level'
            ,array(
                'label' 		=> esc_html__( 'Only display the first level', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'show_view_more_button'
            ,array(
                'label' 		=> esc_html__( 'View More Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )	
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'view_more_text'
            ,array(
                'label' 		=> esc_html__( 'Button Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> 'View more'		
                ,'description' 	=> ''
				,'condition'	=> array( 'show_view_more_button' => '1' )
            )
        );
		
		$this->add_control(
            'view_more_link'
            ,array(
                'label'     		=> esc_html__( 'Button Link', 'themesky' )
                ,'type'     		=> Controls_Manager::URL
				,'default'  		=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
				,'show_external'	=> true
				,'description' 		=> ''
				,'condition'		=> array( 'show_view_more_button' => '1' )
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'image_type'
            ,array(
                'label' 		=> esc_html__( 'Image Type', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'default'
				,'options'		=> array(
									'default'	=> esc_html__( 'Thumbnail', 'themesky' )
									,'icon'		=> esc_html__( 'Icon', 'themesky' )
								)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'img_width'
			,array(
				'label' => esc_html__( 'Image Width', 'themesky' )
				,'type' => Controls_Manager::NUMBER
				,'min' => 50
				,'max' => 300
				,'step' => 1
				,'selectors' => array(
					'{{WRAPPER}} .product-wrapper > a:first-child' => 'width: {{VALUE}}px;'
					,'{{WRAPPER}} .placeholder-items .placeholder-item .placeholder-thumb' => 'max-width: {{VALUE}}px;'
				)
				,'condition'	=> array( 
						'style' => array( 'vertical', 'vertical-2' , 'vertical-3') 
				)
			)
		);
		
		$this->add_responsive_control(
			'img_radius'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Image Radius', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .product-wrapper > a:first-child,
					{{WRAPPER}} .product-wrapper img,
					{{WRAPPER}} .product-category .product-wrapper > a:before,
					{{WRAPPER}} .ts-elementor-lazy-load .placeholder-item .placeholder-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'icon_effect'
            ,array(
                'label' 		=> esc_html__( 'Icon Animation Hover', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'no-effect'
				,'options'		=> array(									
									'eff-buzz' 					=> esc_html__('Buzz', 'themesky')
									,'eff-zoom-in'				=> esc_html__('Zoom in', 'themesky')
									,'no-effect' 				=> esc_html__('None', 'themesky')
								)
                ,'description' 	=> ''
				,'label_block' 	=> true
				,'condition'	=> array( 
						'image_type' => array( 'icon') 
				)
            )
        );
		
		$this->add_control(
			'ts_hr_7'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'vertical'
				,'options'		=> array(
									'vertical'			=> esc_html__( 'Vertical', 'themesky' )
									,'vertical-2'		=> esc_html__( 'Vertical 2', 'themesky' )
									,'overlap'			=> esc_html__( 'Overlap', 'themesky' )
								)			
            )
        );
		
		$this->add_control(
            'show_title'
            ,array(
                'label' 		=> esc_html__( 'Category Title', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_product_count'
            ,array(
                'label' 		=> esc_html__( 'Product Count', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'ts_hr_3'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_responsive_control(
			'content_padding'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Content Padding', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-product-category-wrapper .product-wrapper,
					{{WRAPPER}} .placeholder-items .placeholder-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
				,'condition'	=> array( 
						'style' => array( 'vertical', 'vertical-2' ) 
				)
			)
		);
		
		$this->add_responsive_control(
			'content_margin'
			,array(
				'type' => Controls_Manager::DIMENSIONS
				,'label' => esc_html__( 'Text Margin', 'themesky' )
				,'size_units' => array( 'px', '%', 'em', 'rem' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-product-category-wrapper .product-category .meta-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'ts_alignment'
            ,array(
                'label' 		=> esc_html__( 'Alignment', 'themesky' )
                ,'type' 		=> Controls_Manager::CHOOSE
				,'options' => array(
					'left' => array(
						'title' => esc_html__( 'Left', 'themesky' )
						,'icon' => 'eicon-text-align-left'
					)
					,'center' => array(
						'title' => esc_html__( 'Center', 'themesky' )
						,'icon' => 'eicon-text-align-center'
					)
					,'right' => array(
						'title' => esc_html__( 'Right', 'themesky' )
						,'icon' => 'eicon-text-align-right'
					)
				)
				,'description' 	=> ''
				,'prefix_class' => 'ts-align'
				,'condition'	=> array( 
						'style' => array( 'vertical', 'vertical-2' ) 
				)
            )
        );
		
		$this->add_control(
            'background_color'
            ,array(
                'label'     	=> esc_html__( 'Item Background Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .item-vertical .product-category .product-wrapper,
					{{WRAPPER}} .item-vertical-2 .product-category .product-wrapper > a:first-child,
					{{WRAPPER}} .placeholder-items.item-vertical .placeholder-item ' => 'background: {{VALUE}} !important; border-color: {{VALUE}};'
				)
				,'description' 	=> ''
				,'condition'	=> array( 
						'style' => array( 'vertical','vertical-2' ) 
				)
            )
        );
		
		$this->add_control(
			'ts_hr_8'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
			'item_link'
			,array(
				'label'     	=> esc_html__( 'Item Link', 'themesky' )
				,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
				,'condition'	=> array( 
						'style' => array( 'vertical', 'vertical-2' ) 
				)
			)
		);
		
		$this->add_control(
            'border_color'
            ,array(
                'label'     	=> esc_html__( 'Border Hover', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .item-link .product-wrapper:hover ' => 'border-color: {{VALUE}}'
				)
				,'condition'	=> array( 
					'item_link' => '1'
				)
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );

		$this->add_control(
            'is_slider'
            ,array(
                'label' 		=> esc_html__( 'Enable Slider', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )				
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'only_slider_mobile'
            ,array(
                'label' 		=> esc_html__( 'Only enable slider on device', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> esc_html__( 'Show Grid on desktop and only enable Slider on device', 'themesky' )
            )
        );
		
		$this->add_control(
			'rows'
			,array(
				'label' 		=> esc_html__( 'Rows', 'themesky' )
				,'type' 		=> Controls_Manager::SELECT
				,'default' 		=> '1'
				,'options'		=> array(
									'1'		=> '1'
									,'2'	=> '2'
									,'3'	=> '3'
								)			
				,'description' 	=> ''
			)
		);
		
		$this->add_control(
            'show_nav'
            ,array(
                'label' 		=> esc_html__( 'Show Navigation', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'nav_position'
            ,array(
                'label' 		=> esc_html__( 'Navigation Position', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'center'
				,'options'		=> array(
									'center' 	=> esc_html__('Center', 'themesky')
									,'top' 		=> esc_html__('Top', 'themesky')
								)		
                ,'description' 	=> esc_html__( 'Select type of product', 'themesky' )
            )
        );
		
		$this->add_control(
			'ts_hr_6'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'show_dots'
            ,array(
                'label' 		=> esc_html__( 'Show Bullets', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'auto_play'
            ,array(
                'label' 		=> esc_html__( 'Auto Play', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'loop'
			,array(
				'label' 		=> esc_html__( 'Loop', 'themesky' )
				,'type' 		=> Controls_Manager::SWITCHER
				,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
				,'description' 	=> ''
				)
		);
		
		$this->add_control(
            'disable_slider_responsive'
            ,array(
                'label' 		=> esc_html__( 'Disable Slider Responsive', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )	
                ,'description' 	=> esc_html__( 'You should only enable this option when Columns is 1 or 2', 'themesky' )
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );

		$this->add_responsive_control(
			'items_gap'
			,array(
				'label' => esc_html__( 'Items Gap', 'themesky' )
				,'type' => Controls_Manager::SLIDER
				,'size_units' => array( 'px', '%', 'em', 'rem', 'vw', 'custom' )
				,'default' => array(
					'size' => 30
				)
				,'range' => array(
					'px' => array(
						'min' => 0
						,'max' => 100
					)
				)
				,'description' 	=> esc_html__( 'The spacing between items', 'themesky' )
				,'selectors' => array(
					'{{WRAPPER}} .ts-product-category-wrapper .products.swiper .product'=> 'padding: calc({{SIZE}}{{UNIT}}/2);'
					,'{{WRAPPER}} .ts-product-category-wrapper .products.swiper' => 'margin: calc(-{{SIZE}}{{UNIT}}/2);'
					,'{{WRAPPER}} .ts-product-category-wrapper .products:not(.swiper),
					{{WRAPPER}} .ts-elementor-lazy-load .placeholder-items' => '--ts-h-gap: {{SIZE}}{{UNIT}}; --ts-v-gap: {{SIZE}}{{UNIT}};'
					,'{{WRAPPER}} .ts-product-category-wrapper:not(.nav-top) :is(.swiper-button-prev,.swiper-button-next)' => 'margin-top: calc({{SIZE}}{{UNIT}}/2)'
				)
			)
		);
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_title_font'
            ,array(
                'label'     	=> esc_html__( 'Heading Title', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_title_style_controls();
		
		$this->add_control(
			'ts_hr_4'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_category_font'
            ,array(
                'label'     	=> esc_html__( 'Category Name', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'categories_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#000000'
				,'selectors'	=> array(
					'{{WRAPPER}} .product .meta-wrapper .category-name' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'h_category_typography'
				,'selector'			=> '{{WRAPPER}} .product .meta-wrapper .category-name'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '16'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '20'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array( 'font_style', 'word_spacing')
			)
		);
		
		$this->add_control(
			'ts_hr_5'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'heading_cout_font'
            ,array(
                'label'     	=> esc_html__( 'Count', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'count_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> '#666666'
				,'selectors'	=> array(
					'{{WRAPPER}} .product .meta-wrapper .count' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'h_count_typography'
				,'selector'			=> '{{WRAPPER}} .product .meta-wrapper .count'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '14'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '20'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array( 'font_style', 'word_spacing')
			)
		);
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'						=> 0
			,'title'						=> ''
			,'title_style'					=> 'title-default'
			,'style'						=> 'vertical'
			,'image_type' 					=> 'default'
			,'icon_effect'					=> 'no-effect'
			,'parents' 						=> ''
			,'is_slider'					=> 0
			,'only_slider_mobile'			=> 0
			,'rows' 						=> 1
			,'per_page' 					=> 4
			,'columns' 						=> 6
			,'first_level' 					=> 0
			,'parent' 						=> ''
			,'child_of' 					=> 0
			,'ids'	 						=> ''
			,'hide_empty'					=> 1
			,'show_title'					=> 1
			,'show_view_more_button'		=> 0
			,'view_more_text'				=> ''
			,'view_more_link' 				=> array( 'url' => '', 'is_external' => true, 'nofollow' => true )
			,'show_product_count'			=> 0
			,'show_nav' 					=> 0
			,'nav_position'					=> 'center'
			,'show_dots' 					=> 0
			,'auto_play' 					=> 0
			,'loop' 						=> 1
			,'disable_slider_responsive'	=> 0
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		$link_attr = $this->generate_link_attributes( $view_more_link );
		
		if( !class_exists('WooCommerce') ){
			return;
		}
		
		if( $this->lazy_load_placeholder( $settings, 'product-category' ) ){
			return;
		}

		if( $only_slider_mobile && !wp_is_mobile() ){
			$is_slider = false;
		}
		
		if( is_admin() && !wp_doing_ajax() ){ /* WooCommerce does not include hook below in Elementor editor */
			add_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
		}
		
		if( $image_type == 'icon' ){
			remove_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
			add_action( 'woocommerce_before_subcategory_title', array($this, 'category_icon'), 10 );
		}
		
		if( $first_level ){
			$parent = $child_of = 0;
		}
	
		$parent = is_array($parent) ? implode('', $parent) : $parent;
		$child_of = is_array($child_of) ? implode('', $child_of) : $child_of;

		$args = array(
			'taxonomy'	  => 'product_cat'
			,'orderby'    => 'name'
			,'order'      => 'ASC'
			,'hide_empty' => $hide_empty
			,'pad_counts' => true
			,'parent'     => $parent
			,'child_of'   => $child_of
			,'number'     => $limit
		);
		
		if( $ids ){
			$args['include'] = $ids;
			$args['orderby'] = 'include';
		}
		
		$product_categories = get_terms( $args );
		
		$old_woocommerce_loop_columns = wc_get_loop_prop('columns');
		wc_set_loop_prop('columns', $columns);
		
		wc_set_loop_prop( 'is_shortcode', true );
		
		if( !is_wp_error( $product_categories ) && !empty( $product_categories ) ):
			$classes = array();
			$classes[] = 'ts-product-category-wrapper ts-product ts-shortcode woocommerce';
			$classes[] = 'columns-'.$columns;
			$classes[] = 'item-'.$style;
			$classes[] = $title_style;
			$classes[] = 'nav-'.$nav_position;
			if( $show_dots ){
				$classes[] = 'show-dots';
			}
			if( $show_product_count ){
				$classes[] = 'show-count';
			}
			if( $is_slider ){
				$classes[] = 'ts-slider';
				$classes[] = 'rows-' . $rows;
				if( $show_nav ){
					$classes[] = 'middle-thumbnail';
				}
			}
			if( $item_link ){
				$classes[] = 'item-link';
			}
			if( $image_type == 'icon' ){
				$classes[] = 'thumbnail-icon';
				$classes[] = $icon_effect;
			}
		
			$data_attr = array();
			if( $is_slider ){
				$data_attr[] = 'data-nav="'.$show_nav.'"';
				$data_attr[] = 'data-dots="'.$show_dots.'"';
				$data_attr[] = 'data-autoplay="'.$auto_play.'"';
				$data_attr[] = 'data-loop="'.$loop.'"';
				$data_attr[] = 'data-columns="'.$columns.'"';
				$data_attr[] = 'data-disable_responsive="'.$disable_slider_responsive.'"';
			}
		?>
			<div class="<?php echo esc_attr(implode(' ', $classes)) ?>" style="--ts-columns: <?php echo esc_attr($columns) ?>" <?php echo implode(' ', $data_attr); ?>>
				<?php if( $title ): ?>
				<header class="shortcode-heading-wrapper">
					<h3 class="shortcode-title"><?php echo esc_html($title); ?></h3>
					<?php if( $show_view_more_button && $link_attr ):?>
						<a class="button-text" <?php echo implode(' ', $link_attr); ?>><?php echo esc_html($view_more_text) ?></a>
					<?php endif; ?>
				</header>
				<?php endif; ?>
			
				<div class="content-wrapper <?php echo $is_slider?'loading':''; ?>">
					<?php 
					$count = 0;
					$total_categories = count($product_categories);
					
					woocommerce_product_loop_start();
					foreach( $product_categories as $category ){
						
						if( $is_slider && $rows > 1 && $count % $rows == 0 ){
							echo '<div class="product-group">';
						}
						
						wc_get_template( 'content-product-cat.php', array(
							'category' 						=> $category
							,'style' 						=> $style
							,'show_title' 					=> $show_title
							,'show_product_count' 			=> $show_product_count
						) );
						
						if( $is_slider && $rows > 1 && ( $count % $rows == $rows - 1 || $count == $total_categories - 1 ) ){
							echo '</div>';
						}
					
						$count++;
						
					}
					woocommerce_product_loop_end();
					?>
				</div>
			</div>
		<?php
		endif;
		
		if( $image_type == 'icon' ){
			add_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
			remove_action( 'woocommerce_before_subcategory_title', array($this, 'category_icon'), 10 );
		}
		
		wc_set_loop_prop('columns', $old_woocommerce_loop_columns);
		
		wc_set_loop_prop( 'is_shortcode', false );
	}

	function category_icon( $category ){
		$icon_id = get_term_meta($category->term_id, 'icon_id', true);
		if( $icon_id ){
			echo wp_get_attachment_image( $icon_id, 'full', false, array('alt' => $category->name) );
		}
		else{
			echo wc_placeholder_img();
		}
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Product_Categories() );