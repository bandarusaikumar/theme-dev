<?php
use Elementor\Controls_Manager;

class TS_Elementor_Widget_Filtered_Products extends TS_Elementor_Widget_Base{
	public function get_name(){
        return 'ts-filtered-products';
    }
	
	public function get_title(){
        return esc_html__( 'TS Filtered Products', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements', 'woocommerce-elements' );
    }
	
	public function get_icon(){
		return 'eicon-products';
	}
	
	protected function register_controls(){
		$this->start_controls_section(
            'section_general'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_lazy_load_controls( array( 'thumb-height' => 390 ) );
		
		$this->add_control(
            'title'
            ,array(
                'label' 		=> esc_html__( 'Title', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> ''		
                ,'description' 	=> ''
            )
        );

		$this->add_control(
            'product_type'
            ,array(
                'label' 		=> esc_html__( 'Product type', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'recent'
				,'options'		=> array(
									'recent' 			=> esc_html__('Recent', 'themesky')
									,'sale' 			=> esc_html__('Sale', 'themesky')
									,'best_selling' 	=> esc_html__('Best Selling', 'themesky')
									,'top_rated' 		=> esc_html__('Top Rated', 'themesky')
								)		
                ,'description' 	=> esc_html__( 'Select type of product', 'themesky' )
            )
        );

		$this->add_control(
            'columns'
            ,array(
                'label'     	=> esc_html__( 'Columns', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'		=> 4
				,'min'      	=> 1
            )
        );
		
		$this->add_control(
            'limit'
            ,array(
                'label'     	=> esc_html__( 'Limit', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 8
				,'min'      	=> 1
				,'description' 	=> esc_html__( 'Number of Products', 'themesky' )
            )
        );
		
		$this->add_control(
            'product_cat'
            ,array(
                'label' 		=> esc_html__( 'Product category', 'themesky' )
                ,'type' 		=> 'ts_autocomplete'
                ,'default' 		=> array()
				,'options'		=> array()
				,'autocomplete'	=> array(
					'type'		=> 'taxonomy'
					,'name'		=> 'product_cat'
				)
				,'multiple' 	=> false
				,'sortable' 	=> false
				,'label_block' 	=> true
            )
        );
		
		$this->add_control(
            'show_filter'
            ,array(
                'label' 		=> esc_html__( 'Show Filter', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )	
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'ts_hr_1'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'show_shop_more_button'
            ,array(
                'label' 		=> esc_html__( 'Shop More Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> 	esc_html__( 'No', 'themesky' )	
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'shop_more_button_text'
            ,array(
                'label' 		=> esc_html__( 'Button Text', 'themesky' )
                ,'type' 		=> Controls_Manager::TEXT
                ,'default' 		=> 'Shop now'		
                ,'description' 	=> ''
				,'condition'	=> array( 'show_shop_more_button' => '1' )
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_item'
            ,array(
                'label' 		=> esc_html__( 'Item', 'themesky' )
                ,'tab'   		=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_product_meta_controls();
		
		$this->add_product_color_swatch_controls();
		
		$this->add_responsive_control(
			'max_width'
			,array(
				'label' 		=> esc_html__( 'Max Width', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 100
						,'max' 	=> 500
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .product .product-wrapper' => 'max-width: {{SIZE}}{{UNIT}};margin-right: auto;margin-left: auto'
				)
			)
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_slider'
            ,array(
                'label' 	=> esc_html__( 'Slider', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_CONTENT
            )
        );
		
		$this->add_control(
            'is_slider'
            ,array(
                'label' 		=> esc_html__( 'Enable Slider', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )				
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'only_slider_mobile'
            ,array(
                'label' 		=> esc_html__( 'Only enable slider on device', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> esc_html__( 'Show Grid on desktop and only enable Slider on device', 'themesky' )
            )
        );
		
		$this->add_control(
			'rows'
			,array(
				'label' 		=> esc_html__( 'Rows', 'themesky' )
				,'type' 		=> Controls_Manager::SELECT
				,'default' 		=> '1'
				,'options'		=> array(
									'1'		=> '1'
									,'2'	=> '2'
									,'3'	=> '3'
								)			
				,'description' 	=> ''
			)
		);
		
		$this->add_control(
            'show_nav'
            ,array(
                'label' 		=> esc_html__( 'Show Navigation', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'nav_position'
            ,array(
                'label' 		=> esc_html__( 'Navigation Position', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'center'
				,'options'		=> array(
									'center' 	=> esc_html__('Center', 'themesky')
									,'top' 		=> esc_html__('Top', 'themesky')
								)		
                ,'description' 	=> esc_html__( 'Select type of product', 'themesky' )
            )
        );
		
		$this->add_control(
			'ts_hr_2'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
		
		$this->add_control(
            'show_dots'
            ,array(
                'label' 		=> esc_html__( 'Show Bullets', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'dots_position'
            ,array(
                'label' 		=> esc_html__( 'Dots Position', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'bottom'
				,'options'		=> array(
									'bottom' 		=> esc_html__('Bottom', 'themesky')
									,'left' 		=> esc_html__('Left', 'themesky')
									,'right' 		=> esc_html__('Right', 'themesky')
								)		
                ,'description' 	=> esc_html__( 'Select type of product', 'themesky' )
            )
        );
		
		$this->add_control(
            'auto_play'
            ,array(
                'label' 		=> esc_html__( 'Auto Play', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'loop'
			,array(
				'label' 		=> esc_html__( 'Loop', 'themesky' )
				,'type' 		=> Controls_Manager::SWITCHER
				,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
				,'description' 	=> ''
				)
		);
		
		$this->add_control(
            'disable_slider_responsive'
            ,array(
                'label' 		=> esc_html__( 'Disable Slider Responsive', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )	
                ,'description' 	=> esc_html__( 'You should only enable this option when Columns is 1 or 2', 'themesky' )
            )
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_style'
            ,array(
                'label' 	=> esc_html__( 'General', 'themesky' )
                ,'tab'   	=> Controls_Manager::TAB_STYLE
            )
        );
		
		$this->add_control(
            'heading_title_font'
            ,array(
                'label'     	=> esc_html__( 'Heading Title', 'themesky' )
                ,'type' 		=> Controls_Manager::HEADING		
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'heading_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-shortcode .filter-wrapper,
					{{WRAPPER}} .ts-elementor-lazy-load .placeholder-widget-title' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_control(
            'text_color'
            ,array(
                'label'     	=> esc_html__( 'Text Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-shortcode .filter-wrapper' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_control(
            'text_bold_color'
            ,array(
                'label'     	=> esc_html__( 'Text Bold - Color', 'themesky' )
                ,'type'     	=> Controls_Manager::COLOR
				,'default'  	=> ''
				,'selectors'	=> array(
					'{{WRAPPER}} .ts-filtered-product-wrapper .filter-wrapper > div,
					{{WRAPPER}} .filter-wrapper .dropdown li' => 'color: {{VALUE}}'
				)
            )
        );
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'h_title_typography'
				,'selector'			=> '{{WRAPPER}} .filter-wrapper'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '36'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '42'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_decoration', 'text_transform', 'font_style', 'word_spacing')
			)
		);
		
		$this->end_controls_section();
	}
	
	protected function render(){
		$settings = $this->get_settings_for_display();
		
		$default = array(
			'lazy_load'						=> 0
			,'title'						=> ''
			,'product_type'					=> 'recent'
			,'columns' 						=> 4
			,'limit' 						=> 4
			,'product_cat'					=> ''
			,'show_filter'					=> 1
			,'show_image' 					=> 1
			,'show_gallery' 				=> 0
			,'number_gallery' 				=> 2
			,'show_title' 					=> 1
			,'show_sku' 					=> 0
			,'show_price' 					=> 1
			,'show_short_desc'  			=> 0
			,'show_rating' 					=> 0
			,'show_label' 					=> 1		
			,'show_categories'				=> 0
			,'show_brands'					=> 0
			,'show_add_to_cart' 			=> 1
			,'meta_on_thumbnail'			=> 0
			,'show_color_swatch'			=> 0
			,'number_color_swatch'			=> 3
			,'show_shop_more_button'		=> 0
			,'shop_more_button_text' 		=> 'Shop now'
			,'is_slider'					=> 0
			,'only_slider_mobile'			=> 0
			,'rows' 						=> 1
			,'show_nav'						=> 0
			,'nav_position'					=> 'center'
			,'show_dots'					=> 0
			,'dots_position'				=> 'bottom'
			,'auto_play'					=> 0
			,'loop'							=> 1
			,'disable_slider_responsive'	=> 0
		);
		
		$settings = wp_parse_args( $settings, $default );
		
		extract( $settings );
		
		if ( !class_exists('WooCommerce') ){
			return;
		}
		
		if( $this->lazy_load_placeholder( $settings, 'product' ) ){
			return;
		}
		
		if( $only_slider_mobile && !wp_is_mobile() ){
			$is_slider = 0;
		}

		if( is_array($product_cat) && !$product_cat ){ /* empty array */
			$product_cat = '';
		}
		
		$product_types = ts_get_filtered_product_types( 'label' );
		
		$product_categories = $this->get_product_categories();
		
		$atts = compact('product_type', 'limit', 'product_cat', 'show_image', 'show_gallery', 'number_gallery', 'show_title', 'show_sku'
						, 'show_price', 'show_short_desc', 'show_rating', 'show_label', 'show_categories', 'show_brands', 'show_add_to_cart', 'meta_on_thumbnail'
						, 'show_color_swatch', 'number_color_swatch', 'is_slider', 'rows', 'show_shop_more_button', 'shop_more_button_text');
		
		global $post;
		if( (int)$columns <= 0 ){
			$columns = 4;
		}
	
		$classes = array();
		$classes[] = 'ts-filtered-product-wrapper ts-shortcode ts-product woocommerce';
		$classes[] = 'columns-' . $columns;
		$classes[] = $product_type;
		$classes[] = 'dots-'.$dots_position;
		$classes[] = 'nav-'.$nav_position;
		
		if( $meta_on_thumbnail ){
			$classes[] = 'meta-on-thumbnail';
		}
		
		if( $show_color_swatch ){
			$classes[] = 'show-color-swatch';
		}
		
		if( $is_slider ){
			$classes[] = 'ts-slider ';
			$classes[] = 'rows-' . $rows;
			if( $show_nav ){
				$classes[] = 'middle-thumbnail';
			}
		}
		
		$data_attr = array();
		if( $is_slider ){
			$data_attr[] = 'data-nav="'.$show_nav.'"';
			$data_attr[] = 'data-dots="'.$show_dots.'"';
			$data_attr[] = 'data-autoplay="'.$auto_play.'"';
			$data_attr[] = 'data-loop="'.$loop.'"';
			$data_attr[] = 'data-columns="'.$columns.'"';
			$data_attr[] = 'data-disable_responsive="'.$disable_slider_responsive.'"';
		}
		?>
		<div class="<?php echo esc_attr(implode(' ', $classes)); ?>" style="--ts-columns: <?php echo esc_attr($columns) ?>" <?php echo implode(' ', $data_attr) ?> data-atts="<?php echo htmlentities(json_encode($atts)); ?>">
		
			<?php if( $title ){ ?>
			<header class="shortcode-heading-wrapper">
				<h3 class="shortcode-title">
					<?php echo esc_html($title); ?>
				</h3>
			</header>
			<?php } ?>
			
			<?php if( $show_filter ){ ?>
			<div class="filter-wrapper">
				<span><?php esc_html_e('You are looking for', 'themesky'); ?></span>
				
				<?php $this->dropdown_html( $product_types, $product_type, isset($product_types[$product_type]) ? $product_types[$product_type] : __('new arrivals', 'themesky'), 'product-type' ); ?>
				
				<?php if( $product_categories ){ ?>
				
				<span><?php esc_html_e('in', 'themesky'); ?></span>
			
				<?php 
					$current_category_name = __('all categories', 'themesky');
					if( $product_cat ){
						$current_category = get_term( (int) $product_cat, 'product_cat' );
						if( isset($current_category->name) ){
							$current_category_name = $current_category->name;
						}
					}
					
					$this->dropdown_html( $product_categories, $product_cat, $current_category_name, 'categories' );
				}
				?>
			</div>
			<?php } ?>
				
			<div class="content-wrapper <?php echo ($is_slider)?'loading':'' ?>">
				<?php ts_get_filtered_products( $atts ); ?>
			</div>
		</div>
		<?php
	}
	
	function dropdown_html( $options = array(), $current_value = '', $current_label = '', $type = 'product-type' ){
	?>
		<div class="<?php echo $type ?>-dropdown dropdown-container">
			<span class="current"><?php echo esc_html( $current_label ); ?></span>
			<ul class="dropdown">
				<?php foreach( $options as $key => $label ){ ?>
					<li class="<?php echo $key == $current_value ? 'selected' : ''; ?>" data-value="<?php echo $key; ?>"><?php echo esc_html( $label ); ?></li>
				<?php } ?>
			</ul>
		</div>
	<?php
	}
	
	function get_product_categories( $parent = 0, $level = 0 ){
		$options = array();
		$spacing = '';

		if( $level == 0 ){
			$options[''] = __('all categories', 'themesky');
		}

		for( $i = 0; $i < $level; $i++ ){
			$spacing .= '&nbsp;&nbsp;&nbsp;';
		}

		$args = array(
			'taxonomy'		=> 'product_cat'
			,'number'		=> ''
			,'hide_empty'	=> 1
			,'orderby'		=> 'name'
			,'order'		=> 'asc'
			,'parent'		=> $parent
		);

		$categories = get_terms( $args );
		
		$level++;
		if( is_array($categories) ){
			foreach( $categories as $cat ){
				$options[$cat->term_id] = $spacing . $cat->name;
				$sub_categories = $this->get_product_categories( $cat->term_id, $level );
				if( $sub_categories ){
					foreach( $sub_categories as $key => $value ){
						$options[$key] = $value;
					}
				}
			}
		}
		
		return $options;
	}
}

$widgets_manager->register( new TS_Elementor_Widget_Filtered_Products() );