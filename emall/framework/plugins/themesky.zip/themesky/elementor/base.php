<?php
use Elementor\Controls_Manager;

abstract class TS_Elementor_Widget_Base extends Elementor\Widget_Base{
	public function get_name(){
        return 'ts-base';
    }
	
	public function get_title(){
        return esc_html__( 'ThemeSky Base', 'themesky' );
    }
	
	public function get_categories(){
        return array( 'ts-elements' );
    }
	
	/* key|value,key|value => return array */
	public function parse_link_custom_attributes( $custom_attributes ){
		if( !$custom_attributes ){
			return array();
		}
		
		$attributes = array();
		
		$custom_attributes = str_replace(' ', '', $custom_attributes);
		
		$custom_attributes = explode(',', $custom_attributes);
		foreach( $custom_attributes as $custom_attribute ){
			$attr = explode('|', $custom_attribute);
			if( count($attr) == 2 ){
				$attributes[] = $attr;
			}
		}
		
		return $attributes;
	}
	
	public function generate_link_attributes( $link ){
		if( !$link ){
			return array();
		}

		$link_attr = array();
		
		if( $link['url'] ){
			$link_attr[] = 'href="' . esc_url($link['url']) . '"';
			$link_attr[] = $link['is_external'] ? 'target="_blank"' : '';
			$link_attr[] = $link['nofollow'] ? 'rel="nofollow"' : '';
			
			if( !empty($link['custom_attributes']) ){
				$link_custom_attributes = $this->parse_link_custom_attributes( $link['custom_attributes'] );
				foreach( $link_custom_attributes as $attr ){
					$link_attr[] = $attr[0] . '="' . esc_attr($attr[1]) . '"';
				}
			}
		}
		
		return $link_attr;
	}
	
	public function get_custom_taxonomy_options( $tax = '' ){
		if( !$tax ){
			return;
		}
		
		$terms = get_terms( array(
				'taxonomy'		=> $tax
				,'hide_empty'	=> false
				,'fields'		=> 'id=>name'
			) );
			
		return is_array($terms) ? $terms : array();
	}
	
	public function get_custom_post_options( $post_type = 'post' ){
		$args = array(
				'post_type'				=> $post_type
				,'post_status'			=> 'publish'
				,'posts_per_page'		=> -1
			);
			
		$posts = array();
		
		$query_obj = new WP_Query($args);
		if( $query_obj->have_posts() ){
			foreach( $query_obj->posts as $p ){
				$posts[$p->ID] = $p->post_title;
			}
		}
		
		return $posts;
	}
	
	public function add_lazy_load_controls( $args = array() ){
		$this->add_control(
            'lazy_load'
            ,array(
                'label' 		=> esc_html__( 'Lazy Load', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> esc_html__( 'Show placeholder and only load content when users scroll down', 'themesky' )
            )
        );
		
		$this->add_responsive_control(
			'lazy_load_thumb_height'
			,array(
				'label' 		=> isset( $args['thumb-label'] ) ? $args['thumb-label'] : esc_html__( 'Lazy Load - Thumbnail Height', 'themesky' )
				,'type' 		=> Controls_Manager::NUMBER
				,'default'		=> isset( $args['thumb-height'] ) ? $args['thumb-height'] : 300
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-elementor-lazy-load' => '--lazy-thumb-height: {{VALUE}}px'
				)
				,'condition' 	=> array( 'lazy_load' => '1' )
			)
		);
		
		$this->add_control(
			'lazy_hr'
			,array(
                'type' 		=> Controls_Manager::DIVIDER
            )
		);
	}
	
	public function add_title_style_controls( $condition = array() ){
		
		$this->add_control(
            'title_style'
            ,array(
                'label' 		=> esc_html__( 'Style', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> 'title-default'
				,'options'		=> array(
					'title-default'		=> esc_html__( 'Default', 'themesky' )
					,'title-center'		=> esc_html__( 'Center', 'themesky' )
					,'title-line'		=> esc_html__( 'Line', 'themesky' )
				)			
                ,'description' 	=> ''
            )
        );
		
		$this->add_responsive_control(
			'heading_spacing'
			,array(
				'label' 		=> esc_html__( 'Spacing Bottom', 'themesky' )
				,'type' 		=> Controls_Manager::SLIDER
				,'range' 		=> array(
					'px'	=> array(
						'min' 	=> 0
						,'max' 	=> 100
					)
				)
				,'size_units' 	=> array( 'px', '%', 'em', 'rem', 'vw' )
				,'selectors' 	=> array(
					'{{WRAPPER}} .ts-shortcode .shortcode-heading-wrapper,
					{{WRAPPER}} .ts-elementor-lazy-load:not(.type-product-tabs) .placeholder-widget-title ' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				)
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type()
			,array(
				'label' 			=> esc_html__( 'Typography', 'themesky' )
				,'name' 			=> 'h_title_typography'
				,'selector'			=> '{{WRAPPER}} .shortcode-title'
				,'fields_options'	=> array(
					'font_size'			=> array(
						'default'		=> array(
							'size' 		=> '36'
							,'unit' 	=> 'px'
						)
						,'size_units' 	=> array( 'px', 'em', 'rem', 'vw' )
					)
					,'line_height'		=> array(
						'default' 		=> array(
							'size' 		=> '42'
							,'unit' 	=> 'px'
						)
					)
				)
				,'exclude'	=> array('text_decoration', 'text_transform', 'font_style', 'word_spacing')
			)
		);
		
	}

	public function add_product_meta_controls(){
		
		$this->add_control(
            'show_image'
            ,array(
                'label' 		=> esc_html__( 'Product Image', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_gallery'
            ,array(
                'label' 		=> esc_html__( 'Product Gallery', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> esc_html__( 'Include Product Gallery to Product Image and show in a slider', 'themesky' )
            )
        );
		
		$this->add_control(
            'number_gallery'
            ,array(
                'label'     	=> esc_html__( 'Number Of Gallery Items', 'themesky' )
                ,'type'     	=> Controls_Manager::NUMBER
				,'default'  	=> 2
				,'min'      	=> 1
				,'max'      	=> 5
				,'description' 	=> ''
				,'condition' 	=> array( 'show_gallery' => '1' )
            )
        );
		
		$this->add_control(
            'show_title'
            ,array(
                'label' 		=> esc_html__( 'Product Name', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_sku'
            ,array(
                'label' 		=> esc_html__( 'Product SKU', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_price'
            ,array(
                'label' 		=> esc_html__( 'Product Price', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_short_desc'
            ,array(
                'label' 		=> esc_html__( 'Product Description', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_rating'
            ,array(
                'label' 		=> esc_html__( 'Product Rating', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_label'
            ,array(
                'label' 		=> esc_html__( 'Product Label', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_categories'
            ,array(
                'label' 		=> esc_html__( 'Product Categories', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_brands'
            ,array(
                'label' 		=> esc_html__( 'Product Brands', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_add_to_cart'
            ,array(
                'label' 		=> esc_html__( 'Add To Cart Button', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Show', 'themesky' )
				,'label_off'	=> esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'meta_on_thumbnail'
            ,array(
                'label' 		=> esc_html__( 'Meta On Thumbnail', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
                ,'description' 	=> esc_html__( 'Show product meta on thumbnail instead of below. You should only enable this option if meta content is short', 'themesky' )
            )
        );
	}
	
	public function add_product_color_swatch_controls(){
		$this->add_control(
            'show_color_swatch'
            ,array(
                'label' 		=> esc_html__( 'Color swatches', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> 	esc_html__( 'Show', 'themesky' )
				,'label_off'	=> 	esc_html__( 'Hide', 'themesky' )
                ,'description' 	=> esc_html__( 'Show the color attribute of variations. The slug of the color attribute has to be "color"', 'themesky' )
            )
        );
		
		$this->add_control(
            'number_color_swatch'
            ,array(
                'label' 		=> esc_html__( 'Number of color swatches', 'themesky' )
                ,'type' 		=> Controls_Manager::SELECT
                ,'default' 		=> '3'
				,'options'		=> array(
									'2'		=> '2'
									,'3'	=> '3'
									,'4'	=> '4'
									,'5'	=> '5'
									,'6'	=> '6'
								)			
                ,'description' 	=> ''
                ,'condition' 	=> array( 'show_color_swatch' => '1' )
            )
        );
	}
	
	public function add_product_slider_controls( $has_rows = true ){
		$this->add_control(
            'is_slider'
            ,array(
                'label' 		=> esc_html__( 'Enable Slider', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )				
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'only_slider_mobile'
            ,array(
                'label' 		=> esc_html__( 'Only enable slider on device', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> esc_html__( 'Show Grid on desktop and only enable Slider on device', 'themesky' )
            )
        );
		
		if( $has_rows ){
			$this->add_control(
				'rows'
				,array(
					'label' 		=> esc_html__( 'Rows', 'themesky' )
					,'type' 		=> Controls_Manager::SELECT
					,'default' 		=> '1'
					,'options'		=> array(
										'1'		=> '1'
										,'2'	=> '2'
										,'3'	=> '3'
									)			
					,'description' 	=> ''
				)
			);
		}
		
		$this->add_control(
            'show_nav'
            ,array(
                'label' 		=> esc_html__( 'Show Navigation', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_dots'
            ,array(
                'label' 		=> esc_html__( 'Show Bullets', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'auto_play'
            ,array(
                'label' 		=> esc_html__( 'Auto Play', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'loop'
			,array(
				'label' 		=> esc_html__( 'Loop', 'themesky' )
				,'type' 		=> Controls_Manager::SWITCHER
				,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
				,'description' 	=> ''
				)
		);
		
		$this->add_control(
            'disable_slider_responsive'
            ,array(
                'label' 		=> esc_html__( 'Disable Slider Responsive', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )	
                ,'description' 	=> esc_html__( 'You should only enable this option when Columns is 1 or 2', 'themesky' )
            )
        );
	}
	
	public function add_product_slider_controls_basic(){
		
		$this->add_control(
            'show_nav'
            ,array(
                'label' 		=> esc_html__( 'Show Navigation', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )				
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'show_dots'
            ,array(
                'label' 		=> esc_html__( 'Show Bullets', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
            'auto_play'
            ,array(
                'label' 		=> esc_html__( 'Auto Play', 'themesky' )
                ,'type' 		=> Controls_Manager::SWITCHER
                ,'default' 		=> '0'
				,'return_value' => '1'			
                ,'description' 	=> ''
            )
        );
		
		$this->add_control(
			'loop'
			,array(
				'label' 		=> esc_html__( 'Loop', 'themesky' )
				,'type' 		=> Controls_Manager::SWITCHER
				,'default' 		=> '1'
				,'return_value' => '1'
				,'label_on'		=> esc_html__( 'Yes', 'themesky' )
				,'label_off'	=> esc_html__( 'No', 'themesky' )
				,'description' 	=> ''
				)
		);
		
	}
	
	public function lazy_load_placeholder( $settings = array(), $type = 'product' ){
		if( !empty($settings['lazy_load']) && !wp_doing_ajax() && !( \Elementor\Plugin::instance()->editor->is_edit_mode() || \Elementor\Plugin::instance()->preview->is_preview_mode() ) ){
			$global_classes = array();
			$global_classes[] = 'type-' . $type;
			
			if( isset($settings['title_style']) ){
				$global_classes[] = $settings['title_style'];
			}
			if( !empty($settings['meta_on_thumbnail']) ){
				$global_classes[] = 'meta-on-thumbnail';
			}
			if( $type == 'product-tabs' && isset($settings['tab_style']) ){
				$global_classes[] = $settings['tab_style'];
			}
			?>
			<div class="ts-elementor-lazy-load <?php echo esc_attr( implode(' ', $global_classes) ); ?>">
			<?php
				$title 				= isset($settings['title']) ? $settings['title'] : '';
				
				$is_slider 			= !empty($settings['is_slider']) || $type == 'product-brand' || ( isset($settings['layout']) && $settings['layout'] == 'slider' );
				$only_slider_mobile = !empty($settings['only_slider_mobile']);
				if( $only_slider_mobile && !wp_is_mobile() ){
					$is_slider = false;
				}
				
				$columns 	= isset($settings['columns']) ? absint( $settings['columns'] ) : 5;
				$rows 		= isset($settings['rows']) && !wp_is_mobile() ? absint( $settings['rows'] ) : 1;
				$limit 		= isset($settings['limit']) ? absint( $settings['limit'] ) : 5;
				
				if( $is_slider ){
					$count = min( $columns * $rows, $limit );
				}
				else{
					$count = min( $limit, $columns * 3 ); /* show max 3 rows */
				}
				
				if( $type == 'grouped-product' ){
					$columns = 1;
					$count = 3;
				}
				
				$classes = array();
				$classes[] = 'columns-' . $columns;
				if( $is_slider ){
					$classes[] = 'is-slider';
				}
				
				if( $type == 'blog' ){
					if( isset($settings['style']) ){
						$classes[] = 'item-' . $settings['style'];
					}
					if( isset($settings['layout']) ){
						$classes[] = 'style-' . $settings['layout'];
					}
				}
				
				if( $type == 'product-category' && isset($settings['style']) ){
					$classes[] = 'item-' . $settings['style'];
				}
				
				if( $title || !empty($settings['show_filter']) ){
				?>
				<div class="placeholder-widget-title"></div>
				<?php
				}
				
				if( $type == 'product-tabs' ){
				?>
				<div class="placeholder-tabs">
					<div class="placeholder-tab-item"></div>
					<div class="placeholder-tab-item"></div>
				</div>
				<?php
				}
				?>
				
				<div class="placeholder-items <?php echo esc_attr( implode( ' ', $classes ) ); ?>" style="--lazy-cols: <?php echo esc_attr( $columns ); ?>">
				<?php for( $i = 1; $i <= $count; $i++ ){ ?>
					<div class="placeholder-item">
						<div class="placeholder-thumb"></div>
						<?php if( $type != 'logo' && $type != 'product-brand' ){ ?>
							<div class="placeholder-title"></div>
							<?php if( $type != 'product-category' ){ ?>
								<div class="placeholder-subtitle"></div>
							<?php } ?>
						<?php } ?>
					</div>
				<?php }
				?>
				</div>
			</div>
			<?php
			
			return true;
		}
		return false;
	}
}